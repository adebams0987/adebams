<?php
session_start();
include "../pdo.php";

// Check if the form was submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    // Sanitize and collect form data with additional validation
    $title = trim($_POST['title']);
    $price = filter_var($_POST['price'], FILTER_VALIDATE_FLOAT);
    $property_type = $_POST['property_type'];
    $listing_type = $_POST['listing_type'];
    $address = trim($_POST['address']);
    $city = trim($_POST['city']);
    $state = trim($_POST['state']);
    $zip_code = trim($_POST['zip_code']);
    $latitude = filter_var($_POST['latitude'], FILTER_VALIDATE_FLOAT);
    $longitude = filter_var($_POST['longitude'], FILTER_VALIDATE_FLOAT);
    $description = trim($_POST['description']);
    $features = trim($_POST['features']);

    // Check if required fields are filled
    if (empty($title) || empty($price) || empty($address) || empty($city) || empty($state) || empty($zip_code) || empty($description)) {
        $_SESSION['error'] = "All fields are required.";
        header("Location: addProperties.php");
        exit;
    }

    // Validate price
    if ($price === false || $price <= 0) {
        $_SESSION['error'] = "Invalid price. Please enter a valid price.";
        header("Location: addProperties.php");
        exit;
    }

    // Validate latitude and longitude
    if ($latitude === false || $longitude === false) {
        $_SESSION['error'] = "Invalid latitude or longitude.";
        header("Location: addProperties.php");
        exit;
    }

    // Assuming agent ID is stored in session
    $agent_id = $_SESSION['agent_id']; // or any way you fetch the agent_id

    try {
        // Begin transaction for inserting into multiple tables
        $pdo->beginTransaction();

        // Insert into Properties table
        $sql = "INSERT INTO Properties (title, description, price, address, city, state, zip_code, property_type, listing_type, latitude, longitude, features, agent_id)
                VALUES (:title, :description, :price, :address, :city, :state, :zip_code, :property_type, :listing_type, :latitude, :longitude, :features, :agent_id)";
        
        $stmt = $pdo->prepare($sql);
        $stmt->bindParam(':title', $title);
        $stmt->bindParam(':description', $description);
        $stmt->bindParam(':price', $price);
        $stmt->bindParam(':address', $address);
        $stmt->bindParam(':city', $city);
        $stmt->bindParam(':state', $state);
        $stmt->bindParam(':zip_code', $zip_code);
        $stmt->bindParam(':property_type', $property_type);
        $stmt->bindParam(':listing_type', $listing_type);
        $stmt->bindParam(':latitude', $latitude);
        $stmt->bindParam(':longitude', $longitude);
        $stmt->bindParam(':features', $features);
        $stmt->bindParam(':agent_id', $agent_id);

        $stmt->execute();
        $property_id = $pdo->lastInsertId(); // Get the inserted property ID

        // Handle property images upload
        if (isset($_FILES['property_images']) && !empty($_FILES['property_images']['name'][0])) {
            $uploadDirectory = "../Images/uploads/"; // Your upload folder path

            // Ensure the upload directory exists and is writable
            if (!is_dir($uploadDirectory)) {
                mkdir($uploadDirectory, 0777, true); // Create the directory if it doesn't exist
            }

            // Allowed image types and max file size (e.g., 2MB)
            $allowedMimeTypes = ['image/jpeg', 'image/png'];
            $maxFileSize = 2 * 1024 * 1024; // 2MB

            foreach ($_FILES['property_images']['tmp_name'] as $key => $tmpName) {
                $fileName = $_FILES['property_images']['name'][$key];
                $fileTmpPath = $_FILES['property_images']['tmp_name'][$key];
                $fileMimeType = mime_content_type($fileTmpPath);
                $fileSize = $_FILES['property_images']['size'][$key];

                // Check if the file type is allowed
                if (!in_array($fileMimeType, $allowedMimeTypes)) {
                    $_SESSION['error'] = "Invalid file type. Only JPEG and PNG images are allowed.";
                    header("Location: addProperties.php");
                    exit;
                }

                // Check if the file size is within the limit
                if ($fileSize > $maxFileSize) {
                    $_SESSION['error'] = "File size exceeds the maximum limit of 2MB.";
                    header("Location: addProperties.php");
                    exit;
                }

                // Handle file upload errors
                if ($_FILES['property_images']['error'][$key] != UPLOAD_ERR_OK) {
                    $_SESSION['error'] = "Error uploading file: " . $_FILES['property_images']['error'][$key];
                    header("Location: addProperties.php");
                    exit;
                }

                // Generate a unique name for each file
                $fileDestination = $uploadDirectory . uniqid() . '_' . basename($fileName);

                // Move the file to the desired location
                if (move_uploaded_file($fileTmpPath, $fileDestination)) {
                    // Insert the image URL into the Property_Images table
                    $sql = "INSERT INTO Property_Images (property_id, image_url) VALUES (:property_id, :image_url)";
                    $stmt = $pdo->prepare($sql);
                    $stmt->bindParam(':property_id', $property_id);
                    $stmt->bindParam(':image_url', $fileDestination);
                    $stmt->execute();
                }
            }
        }

        // Commit the transaction
        $pdo->commit();
        
        // Set success message and redirect
        $_SESSION['success'] = "Property added successfully!";
        header("Location: agentProperties.php");
        exit;

    } catch (Exception $e) {
        // Rollback if something goes wrong
        $pdo->rollBack();
        
        // Set error message and redirect
        $_SESSION['error'] = "Error: " . $e->getMessage();
        header("Location: addProperties.php");
        exit;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Properties</title>

    <!-- Favicon Links -->
    <link rel="apple-touch-icon" sizes="180x180" href="../Fonts/apple-touch-icon.png">
    <link rel="icon" type="image/png" sizes="32x32" href="../Fonts/favicon-32x32.png">

    <!-- CSS Links -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://unicons.iconscout.com/release/v4.0.8/css/line.css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css" rel="stylesheet">

    <style>
         body {
            background-color: #f8f9fa;
        }
        
        .form-container {
            background: white;
            border-radius: 15px;
            box-shadow: 0 0 20px rgba(0,0,0,0.05);
        }

        .form-label {
            font-weight: 600;
            color: #344767;
        }

        .form-control, .form-select {
            border-radius: 8px;
            border: 1px solid #dee2e6;
            padding: 12px 15px;
        }

        .form-control:focus, .form-select:focus {
            box-shadow: 0 0 0 0.25rem rgba(13,110,253,.15);
        }

        .image-upload {
            border: 2px dashed #dee2e6;
            border-radius: 8px;
            padding: 20px;
            text-align: center;
            cursor: pointer;
            transition: all 0.3s ease;
        }

        .image-upload:hover {
            border-color: #0d6efd;
            background-color: #f8f9fa;
        }

        .submit-btn {
            padding: 12px 30px;
            font-weight: 600;
            border-radius: 8px;
            transition: all 0.3s ease;
        }

        .submit-btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
        }

        .section-title {
            color: #344767;
            font-weight: 600;
            padding-bottom: 10px;
            border-bottom: 2px solid #eee;
            margin-bottom: 20px;
        }

        .progress {
            height: 20px;
            margin-top: 20px;
        }
    </style>
</head>
<body>
    <?php include "../header.php"; ?>

    <div class="container py-5">
        <div class="form-container p-4 p-md-5">
            <h2 class="text-center mb-4">Add New Property</h2>
            
            <!-- Display session messages -->
            <?php if (isset($_SESSION['error'])): ?>
                <div class="alert alert-danger alert-dismissible fade show" role="alert">
                    <?php echo $_SESSION['error']; ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
                <?php
                // Clear session messages
                unset($_SESSION['error']);
                ?>
            <?php endif; ?>

            <?php if (isset($_SESSION['success'])): ?>
                <div class="alert alert-success alert-dismissible fade show" role="alert">
                    <?php echo $_SESSION['success']; ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
                <?php
                // Clear session messages
                unset($_SESSION['success']);
                ?>
            <?php endif; ?>

            <form id="propertyForm" action="addproperties.php" method="POST" enctype="multipart/form-data">
                <!-- Basic Information Section -->
                <h4 class="section-title">Basic Information</h4>
                <div class="row g-4 mb-5">
                    <div class="col-md-6">
                        <label class="form-label" for="title">Property Title*</label>
                        <input type="text" class="form-control" id="title" name="title" required>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label" for="price">Price*</label>
                        <div class="input-group">
                            <span class="input-group-text">$</span>
                            <input type="number" class="form-control" id="price" name="price" step="0.01" required>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label" for="property_type">Property Type*</label>
                        <select class="form-select" id="property_type" name="property_type" required>
                            <option value="residential">Residential</option>
                            <option value="commercial">Commercial</option>
                        </select>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label" for="listing_type">Listing Type*</label>
                        <select class="form-select" id="listing_type" name="listing_type" required>
                            <option value="sale">For Sale</option>
                            <option value="rent">For Rent</option>
                        </select>
                    </div>
                </div>

                <!-- Location Section -->
                <h4 class="section-title">Location Details</h4>
                <div class="row g-4 mb-5">
                    <div class="col-md-6">
                        <label class="form-label" for="address">Street Address*</label>
                        <input type="text" class="form-control" id="address" name="address" required>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label" for="city">City*</label>
                        <input type="text" class="form-control" id="city" name="city" required>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label" for="state">State*</label>
                        <input type="text" class="form-control" id="state" name="state" required>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label" for="zip_code">ZIP Code*</label>
                        <input type="text" class="form-control" id="zip_code" name="zip_code" required>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label" for="latitude">Latitude*</label>
                        <input type="number" class="form-control" id="latitude" name="latitude" step="0.000001" required>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label" for="longitude">Longitude*</label>
                        <input type="number" class="form-control" id="longitude" name="longitude" step="0.000001" required>
                    </div>
                </div>

                <!-- Property Details Section -->
                <h4 class="section-title">Property Details</h4>
                <div class="row g-4 mb-5">
                    <div class="col-12">
                        <label class="form-label" for="description">Description*</label>
                        <textarea class="form-control" id="description" name="description" rows="4" required></textarea>
                    </div>
                    <div class="col-12">
                        <label class="form-label" for="features">Features*</label>
                        <textarea class="form-control" id="features" name="features" rows="3" 
                                placeholder="Enter features separated by commas (e.g., 3 Bedrooms, 2 Bathrooms, Garden)" required></textarea>
                    </div>
                </div>

                <!-- Images Section -->
                <h4 class="section-title">Property Images</h4>
                <div class="row g-4 mb-5">
                    <div class="col-12">
                        <div class="image-upload">
                            <input type="file" class="form-control" id="property_images" name="property_images[]" multiple accept="image/*">
                            <p class="text-muted mt-2">
                                <i class="fas fa-cloud-upload-alt fa-2x mb-2"></i><br>
                                Drag and drop images here or click to upload
                            </p>
                        </div>
                    </div>
                </div>

                <!-- Progress Bar -->
                <div class="progress">
                    <div id="progressBar" class="progress-bar" role="progressbar" style="width: 0%;" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100"></div>
                </div>

                <!-- Submit Button -->
                <div class="text-center mt-5">
                    <button type="submit" class="btn btn-primary submit-btn">
                        <i class="fas fa-plus-circle me-2"></i>Add Property
                    </button>
                </div>
            </form>
        </div>
    </div>

    <?php include "../footer.php"; ?>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.2/js/bootstrap.bundle.min.js"></script>
    <script>
        document.getElementById('propertyForm').addEventListener('submit', function(event) {
            event.preventDefault();
            var form = event.target;
            var formData = new FormData(form);

            // Client-side file validation
            var files = document.getElementById('property_images').files;
            var allowedMimeTypes = ['image/jpeg', 'image/png'];
            var maxFileSize = 5 * 1024 * 1024; // 5MB

            for (var i = 0; i < files.length; i++) {
                var file = files[i];

                if (!allowedMimeTypes.includes(file.type)) {
                    alert('Invalid file type. Only JPEG and PNG images are allowed.');
                    return;
                }

                if (file.size > maxFileSize) {
                    alert('File size exceeds the maximum limit of 5MB.');
                    return;
                }
            }

            var xhr = new XMLHttpRequest();
            xhr.open('POST', form.action, true);

            xhr.upload.addEventListener('progress', function(e) {
                if (e.lengthComputable) {
                    var percentComplete = (e.loaded / e.total) * 100;
                    var progressBar = document.getElementById('progressBar');
                    progressBar.style.width = percentComplete + '%';
                    progressBar.setAttribute('aria-valuenow', percentComplete);
                }
            });

            xhr.addEventListener('load', function() {
                if (xhr.status === 200) {
                    window.location.href = 'agentProperties.php';
                } else {
                    alert('An error occurred while uploading the files.');
                }
            });

            xhr.send(formData);
        });
    </script>
</body>
</html>