<?php
session_start();
include "../pdo.php";
include "processAgent.php";

$user_id = $_SESSION['user_id'] ?? null;
$incompleteProfile = false;
$missingFields = [];

if ($user_id) {
    $stmt = $pdo->prepare("SELECT license_number, agency_name, profile_picture FROM Agents WHERE user_id = ?");
    $stmt->execute([$user_id]);
    $agent = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($agent) {
        foreach ($agent as $key => $value) {
            if (empty($value)) {
                $incompleteProfile = true;
                $missingFields[] = ucfirst(str_replace("_", " ", $key));
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Agent Dashboard</title>

    <!-- Favicon Links -->
    <link rel="apple-touch-icon" sizes="180x180" href="../Fonts/apple-touch-icon.png">
    <link rel="icon" type="image/png" sizes="32x32" href="../Fonts/favicon-32x32.png">

    <!-- CSS Links -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://unicons.iconscout.com/release/v4.0.8/css/line.css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css" rel="stylesheet">

</head>
<body class="d-flex flex-column min-vh-100">
    <?php include "../header.php"; ?>

    <?php if ($incompleteProfile): ?>
        <div class="alert alert-warning text-center">
            <strong>Warning!</strong> Your profile is incomplete. Please update the following fields: 
            <?= implode(", ", $missingFields); ?>
            <br>
            <a href="agentProfile.php" class="btn btn-sm btn-primary mt-2">Update Profile</a>
        </div>
    <?php endif; ?>

    <div class="container flex-grow-1">
        <div class="row">
            <!-- Main Content -->
            <main class="container px-3 px-md-4">
                <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                    <h1 class="h2">Dashboard</h1>
                    <div class="btn-toolbar mb-2 mb-md-0">
                        <div class="btn-group me-2">
                            <a href="addProperties.php" class="btn btn-sm btn-outline-primary">Add Property</a>
                            <button type="button" class="btn btn-sm btn-outline-secondary">Generate Report</button>
                        </div>
                    </div>
                </div>

                <!-- Stats Cards -->
                <div class="row g-3 mb-4">
                    <div class="col-md-3">
                        <div class="card text-white bg-primary">
                            <div class="card-body">
                                <h5 class="card-title">Active Listings</h5>
                                <h2><?= $activeListings ?></h2>
                                <small>Updated now</small>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="card text-white bg-success">
                            <div class="card-body">
                                <h5 class="card-title">Properties Sold</h5>
                                <h2><?= $propertiesSold ?></h2>
                                <small>This month</small>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="card text-white bg-info">
                            <div class="card-body">
                                <h5 class="card-title">New Inquiries</h5>
                                <h2><?= $newInquiries ?></h2>
                                <small>Last 7 days</small>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="card text-white bg-warning">
                            <div class="card-body">
                                <h5 class="card-title">Revenue</h5>
                                <?php
                                    if ($revenue >= 1000000) {
                                        $formattedRevenue = number_format($revenue / 1000000, 1) . 'M';
                                    } elseif ($revenue >= 1000) {
                                        $formattedRevenue = number_format($revenue / 1000, 1) . 'K';
                                    } else {
                                        $formattedRevenue = number_format($revenue, 0);
                                    }
                                ?>
                                <h2>$<?= $formattedRevenue ?></h2>
                                <small>This month</small>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="card text-white bg-secondary">
                            <div class="card-body">
                                <h5 class="card-title">Properties Rented</h5>
                                <h2><?= $rentedProperties ?></h2>
                                <small>This month</small>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Property Listings -->
                <div class="row mb-4">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-header d-flex justify-content-between align-items-center">
                                <h5 class="mb-0">Property Listings</h5>
                                <div class="btn-group">
                                    <a href="?type=All" class="btn btn-sm btn-outline-secondary <?= $filter === 'All' ? 'active' : '' ?>">All</a>
                                    <a href="?type=Commercial" class="btn btn-sm btn-outline-secondary <?= $filter === 'Commercial' ? 'active' : '' ?>">Commercial</a>
                                    <a href="?type=Residential" class="btn btn-sm btn-outline-secondary <?= $filter === 'Residential' ? 'active' : '' ?>">Residential</a>
                                </div>
                            </div>
                            <div class="card-body">
                                <div class="table-responsive">
                                    <table class="table table-hover">
                                        <thead>
                                            <tr>
                                                <th>Property</th>
                                                <th>Type</th>
                                                <th>Location</th>
                                                <th>Price</th>
                                                <th>Status</th>
                                                <th>Actions</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php if (!empty($properties)): ?>
                                                <?php foreach ($properties as $property): ?>
                                                    <tr>
                                                        <td>
                                                            <img src="<?= htmlspecialchars($property['image_url'] ?? '/api/placeholder/40/40') ?>" 
                                                                class="me-2" alt="Property" style="max-width: 50px; max-height: 30px; object-fit: cover;">
                                                            <?= htmlspecialchars($property['title']) ?>
                                                        </td>

                                                        <td><?= ucfirst(htmlspecialchars($property['property_type'])) ?></td>
                                                        <td><?= htmlspecialchars($property['city'] . ', ' . $property['state']) ?></td>
                                                        <td>$<?= number_format($property['price'], 2) ?></td>
                                                        <td>
                                                            <span class="badge bg-<?= $property['status'] === 'available' ? 'success' : ($property['status'] === 'sold' ? 'danger' : 'warning') ?>">
                                                                <?= ucfirst(htmlspecialchars($property['status'])) ?>
                                                            </span>
                                                        </td>
                                                        <td>
                                                            <a href="editProperties.php?property_id=<?= $property['property_id'] ?>" class="btn btn-sm btn-outline-success">Edit</a>
                                                            <a href="deleteProperties.php?property_id=<?= $property['property_id'] ?>" class="btn btn-sm btn-outline-danger">Delete</a>
                                                        </td>
                                                    </tr>
                                                <?php endforeach; ?>
                                            <?php else: ?>
                                                <tr>
                                                    <td colspan="6" class="text-center">No properties found.</td>
                                                </tr>
                                            <?php endif; ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Recent Activity and Upcoming Appointments -->
                <div class="row">
                    <!-- Recent Activity -->
                    <div class="col-md-6 mb-4">
                        <div class="card">
                            <div class="card-header">
                                <h5 class="mb-0">Recent Activity</h5>
                            </div>
                            <div class="card-body">
                                <div class="list-group list-group-flush">
                                    <?php if (!empty($recentActivities)): ?>
                                        <?php foreach (array_slice($recentActivities, 0, 5) as $activity): ?>
                                            <div class="list-group-item">
                                                <div class="d-flex w-100 justify-content-between">
                                                    <h6 class="mb-1"><?= htmlspecialchars($activity['activity_title']) ?></h6>
                                                    <small><?= htmlspecialchars($activity['time_elapsed'] < 60 ? $activity['time_elapsed'] . ' mins ago' : round($activity['time_elapsed'] / 60) . ' hours ago') ?></small>
                                                </div>
                                                <p class="mb-1"><?= htmlspecialchars($activity['activity_description']) ?></p>
                                            </div>
                                        <?php endforeach; ?>
                                    <?php else: ?>
                                        <p class="text-center">No recent activity found.</p>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Upcoming Appointments -->
                    <div class="col-md-6 mb-4">
                        <div class="card">
                            <div class="card-header">
                                <h5 class="mb-0">Upcoming Appointments</h5>
                            </div>
                            <div class="card-body">
                                <div class="list-group list-group-flush">
                                    <?php if (!empty($appointments)): ?>
                                        <?php foreach (array_slice($appointments, 0, 5) as $appointment): ?>
                                            <div class="list-group-item">
                                                <div class="d-flex w-100 justify-content-between">
                                                    <h6 class="mb-1"><?= htmlspecialchars($appointment['client_name']) ?></h6>
                                                    <small><?= htmlspecialchars($appointment['appointment_date'] . ' ' . $appointment['time_slot']) ?></small>
                                                </div>
                                                <p class="mb-1">
                                                    <?= htmlspecialchars($appointment['appointment_type']) ?>
                                                    <?php if ($appointment['property_name']): ?>
                                                        - <?= htmlspecialchars($appointment['property_name']) ?>
                                                    <?php endif; ?>
                                                </p>
                                            </div>
                                        <?php endforeach; ?>
                                    <?php else: ?>
                                        <p class="text-center">No upcoming appointments found.</p>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </main>
        </div>
    </div>

    <?php include "../footer.php"; ?>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
   
</body>
</html>