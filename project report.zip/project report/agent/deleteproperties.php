<?php
session_start();
include "../pdo.php";

// Fetch property ID from query parameter (Ensure it's sanitized)
$property_id = isset($_GET['property_id']) ? (int)$_GET['property_id'] : 0;
if (!$property_id) {
    die("Property ID is required.");
}

// Fetch property details
$property_sql = "SELECT * FROM Properties WHERE property_id = :property_id";
$property_stmt = $pdo->prepare($property_sql);
$property_stmt->execute(['property_id' => $property_id]);
$property = $property_stmt->fetch(PDO::FETCH_ASSOC);

if (!$property) {
    $_SESSION['error'] = "Property not found.";
    header("Location: agentProperties.php");
    exit;
}

// Fetch property images
$image_sql = "SELECT * FROM Property_Images WHERE property_id = :property_id";
$image_stmt = $pdo->prepare($image_sql);
$image_stmt->execute(['property_id' => $property_id]);
$images = $image_stmt->fetchAll(PDO::FETCH_ASSOC);

// Check if the form is submitted to delete the property
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['property_id'])) {
    $property_id = (int)$_POST['property_id'];

    if (!$property_id) {
        $_SESSION['error'] = "Invalid property ID.";
        header("Location: agentProperties.php");
        exit;
    }

    try {
        // Begin transaction to ensure atomic deletion
        $pdo->beginTransaction();

        // Delete associated property images
        $delete_images_sql = "DELETE FROM Property_Images WHERE property_id = :property_id";
        $delete_images_stmt = $pdo->prepare($delete_images_sql);
        $delete_images_stmt->execute(['property_id' => $property_id]);

        // Delete appointments associated with the property
        $delete_appointments_sql = "DELETE FROM appointments WHERE property_id = :property_id";
        $delete_appointments_stmt = $pdo->prepare($delete_appointments_sql);
        $delete_appointments_stmt->execute(['property_id' => $property_id]);

        // Delete saved references to the property
        $delete_saved_properties_sql = "DELETE FROM saved_properties WHERE property_id = :property_id";
        $delete_saved_properties_stmt = $pdo->prepare($delete_saved_properties_sql);
        $delete_saved_properties_stmt->execute(['property_id' => $property_id]);

        // Delete the property itself
        $delete_property_sql = "DELETE FROM Properties WHERE property_id = :property_id";
        $delete_property_stmt = $pdo->prepare($delete_property_sql);
        $delete_property_stmt->execute(['property_id' => $property_id]);

        // Commit the transaction
        $pdo->commit();

        $_SESSION['success'] = "Property deleted successfully.";
        header("Location: agentProperties.php");
        exit;

    } catch (Exception $e) {
        // Rollback the transaction if something goes wrong
        $pdo->rollBack();
        $_SESSION['error'] = "Error deleting property: " . $e->getMessage();
        header("Location: agentProperties.php");
        exit;
    }
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Delete Property</title>

<!-- CSS & Icons -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css" rel="stylesheet">
<style>
   .property-header {
            background: linear-gradient(rgba(0,0,0,0.7), rgba(0,0,0,0.7)),
                        url('/api/placeholder/1920/400');
            background-size: cover;
            background-position: center;
            color: white;
            padding: 4rem 0;
            margin-bottom: 2rem;
        }
        .carousel-item img {
            height: 500px;
            object-fit: cover;
            border-radius: 10px;
        }
        .feature-list {
            list-style: none;
            padding-left: 0;
            columns: 2;
            gap: 2rem;
        }
        .feature-list li {
            margin-bottom: 1rem;
        }
        .agent-card {
            transition: transform 0.3s ease;
        }
        .agent-card:hover {
            transform: translateY(-5px);
        }
        .price-badge {
            font-size: 1.5rem;
            padding: 0.5rem 1.5rem;
            border-radius: 50px;
        }
        .action-buttons {
            position: fixed;
            bottom: 0;
            left: 0;
            right: 0;
            background: rgba(255, 255, 255, 0.95);
            box-shadow: 0 -2px 10px rgba(0,0,0,0.1);
            padding: 1rem 0;
            z-index: 1000;
        }
        .btn-delete {
            transition: all 0.3s ease;
        }
        .btn-delete:hover {
            transform: scale(1.05);
            background-color: #dc3545;
            border-color: #dc3545;
            color: white;
        }
</style>
</head>
<body>
    
    <?php include "../header.php"; ?>

    <?php
        if (!empty($_SESSION['error'])) {
            echo '<div class="alert alert-danger" role="alert">';
            echo htmlspecialchars($_SESSION['error']);
            echo '</div>';
            unset($_SESSION['error']); // Clear the message after displaying it
        }

        if (!empty($_SESSION['success'])) {
            echo '<div class="alert alert-success" role="alert">';
            echo htmlspecialchars($_SESSION['success']);
            echo '</div>';
            unset($_SESSION['success']); // Clear the message after displaying it
        }
    ?>

    <div class="mt-5"></div>
    <div class="mt-5"></div>
    <div class="container">
        <div class="row">
            <!-- Property Images -->
            <div class="col-md-6">
                <?php if ($images): ?>
                    <div id="propertyCarousel" class="carousel slide" data-bs-ride="carousel">
                        <div class="carousel-inner">
                            <?php foreach ($images as $index => $image): ?>
                                <div class="carousel-item <?= $index === 0 ? 'active' : '' ?>">
                                    <img src="<?= htmlspecialchars($image['image_url']) ?>" 
                                        class="d-block w-100" 
                                        alt="Property Image <?= $index + 1 ?>">
                                </div>
                            <?php endforeach; ?>
                        </div>
                        <button class="carousel-control-prev" type="button" data-bs-target="#propertyCarousel" data-bs-slide="prev">
                            <span class="carousel-control-prev-icon"></span>
                            <span class="visually-hidden">Previous</span>
                        </button>
                        <button class="carousel-control-next" type="button" data-bs-target="#propertyCarousel" data-bs-slide="next">
                            <span class="carousel-control-next-icon"></span>
                            <span class="visually-hidden">Next</span>
                        </button>
                    </div>
                <?php else: ?>
                    <div class="alert alert-info">
                        <i class="fas fa-info-circle me-2"></i>
                        No images available for this property.
                    </div>
                <?php endif; ?>
            </div>

            <!-- Property Details -->
            <div class="col-md-6">
                <div class="card shadow-sm mb-4">
                    <div class="card-body">
                        <h2 class="card-title border-bottom pb-3 mb-4">
                            <i class="fas fa-info-circle me-2 text-primary"></i>
                            Description
                        </h2>

                        <p class="lead">
                            <strong>Property Name:</strong> <?= htmlspecialchars($property['title']) ?><br>
                            <strong>Price:</strong> $<?= number_format($property['price'], 2) ?><br>
                            <strong>Location:</strong> <?= htmlspecialchars($property['address']) ?>, 
                            <?= htmlspecialchars($property['city']) ?>, <?= htmlspecialchars($property['state']) ?><br><br>
                        </p>

                        <p class="lead">
                            <?= nl2br(htmlspecialchars($property['description'])) ?>
                        </p>

                        <h2 class="card-title border-bottom pb-3 mb-4 mt-5">
                            <i class="fas fa-star me-2 text-primary"></i>
                            Features
                        </h2>
                        <ul class="feature-list">
                            <?php
                            $features = array_filter(array_map('trim', explode(',', $property['features']))); 
                            if ($features):
                                foreach ($features as $feature): ?>
                                    <li>
                                        <i class="fas fa-check-circle text-success me-2"></i>
                                        <?= htmlspecialchars($feature) ?>
                                    </li>
                                <?php endforeach;
                            else: ?>
                                <li class="text-muted">
                                    <i class="fas fa-info-circle me-2"></i>
                                    No features listed for this property.
                                </li>
                            <?php endif; ?>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Action Buttons Fixed at Bottom -->
    <div class="action-buttons">
        <div class="container">
            <div class="row justify-content-end">
                <div class="col-12 col-md-4">
                    <div class="d-grid gap-2 d-md-flex justify-content-md-end">
                        <button type="button" class="btn btn-outline-danger btn-lg" data-bs-toggle="modal" data-bs-target="#deleteModal">
                            <i class="fas fa-trash-alt me-2"></i>Delete Property
                        </button>
                        <a href="agentProperties.php" class="btn btn-secondary btn-lg">
                            <i class="fas fa-times me-2"></i>Cancel
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Delete Confirmation Modal -->
    <div class="modal fade" id="deleteModal" tabindex="-1" aria-labelledby="deleteModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header bg-danger text-white">
                    <h5 class="modal-title" id="deleteModalLabel">
                        <i class="fas fa-exclamation-triangle me-2"></i>Confirm Deletion
                    </h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <p class="lead">Are you sure you want to delete this property?</p>
                    <div class="alert alert-warning">
                        <i class="fas fa-exclamation-circle me-2"></i> This action cannot be undone.
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">
                        <i class="fas fa-times me-2"></i>Cancel
                    </button>
                    <form method="POST" action="deleteProperties.php" style="display: inline;">
                        <input type="hidden" name="property_id" value="<?= htmlspecialchars($property['property_id']) ?>">
                        <button type="submit" class="btn btn-danger">
                            <i class="fas fa-trash-alt me-2"></i>Delete Property
                        </button>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <div class="mt-5"></div>
    <?php include "../footer.php"; ?>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
