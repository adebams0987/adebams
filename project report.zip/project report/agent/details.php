<?php
session_start();
include "../pdo.php";

if (!isset($_GET['type']) || !isset($_GET['id'])) {
    echo "Invalid request.";
    exit();
}

$type = $_GET['type'];
$id = $_GET['id'];

try {
    if ($type == 'openhouse') {
        $sql = "SELECT a.id, a.first_name, a.last_name, a.email, a.phone, a.appointment_date, a.time_slot, a.appointment_type, a.notes,
                       p.title, p.address, p.city, p.state, pi.image_url
                FROM appointments a
                LEFT JOIN properties p ON a.property_id = p.property_id
                LEFT JOIN property_images pi ON p.property_id = pi.property_id
                WHERE a.id = :id";
    } elseif ($type == 'consultation') {
        $sql = "SELECT a.id, a.first_name, a.last_name, a.email, a.phone, a.appointment_date, a.time_slot, a.appointment_type, a.notes
                FROM appointments a
                WHERE a.id = :id";
    } elseif ($type == 'inquiry') {
        $sql = "SELECT cm.id, cm.email AS sender_email, cm.message, cm.created_at AS date, 
                       p.title, p.address
                FROM contact_messages cm
                LEFT JOIN properties p ON cm.property_id = p.property_id
                WHERE cm.id = :id";
    } else {
        echo "Invalid type.";
        exit();
    }

    $stmt = $pdo->prepare($sql);
    $stmt->execute(['id' => $id]);
    $details = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$details) {
        echo "No details found.";
        exit();
    }
} catch (PDOException $e) {
    echo "Error fetching details: " . $e->getMessage();
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Details</title>

    <!-- Favicon Links -->
    <link rel="apple-touch-icon" sizes="180x180" href="../Fonts/apple-touch-icon.png">
    <link rel="icon" type="image/png" sizes="32x32" href="../Fonts/favicon-32x32.png">

    <!-- CSS Links -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://unicons.iconscout.com/release/v4.0.8/css/line.css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css" rel="stylesheet">
    <style>
        body {
            font-family: 'Roboto', sans-serif;
        }
        .profile-picture {
            width: 50px;
            height: 50px;
            border-radius: 50%;
        }
        .card-header {
            background-color: #f8f9fa;
        }
        .card-body {
            padding: 1rem;
        }
        .card {
            margin-bottom: 1rem;
        }
    </style>
</head>

<body>
    <?php include "../header.php"; ?>

    <div class="container mt-5">
        <div class="card mb-4">
            <div class="card-header">
                <h5>Details</h5>
            </div>
            <div class="card-body">
                <?php if ($type == 'openhouse'): ?>
                    <h5 class="card-title"><?php echo htmlspecialchars($details['title'] ?? ''); ?></h5>
                    <p class="card-text"><?php echo htmlspecialchars($details['address'] ?? '') . ', ' . htmlspecialchars($details['city'] ?? '') . ', ' . htmlspecialchars($details['state'] ?? ''); ?></p>
                    <p class="card-text">
                        <small class="text-muted"><?php echo ucfirst($details['appointment_type'] ?? '') . ': ' . htmlspecialchars($details['appointment_date'] ?? '') . ' at ' . htmlspecialchars($details['time_slot'] ?? ''); ?></small>
                    </p>
                    <p class="card-text">Client: <?php echo htmlspecialchars($details['first_name'] ?? '') . ' ' . htmlspecialchars($details['last_name'] ?? ''); ?></p>
                    <p class="card-text">Email: <?php echo htmlspecialchars($details['email'] ?? ''); ?></p>
                    <p class="card-text">Phone: <?php echo htmlspecialchars($details['phone'] ?? ''); ?></p>
                    <p class="card-text">Notes: <?php echo htmlspecialchars($details['notes'] ?? ''); ?></p>
                    <?php if (!empty($details['image_url'])): ?>
                        <img src="<?php echo htmlspecialchars($details['image_url']); ?>" alt="Property Image" class="img-fluid">
                    <?php endif; ?>
                <?php elseif ($type == 'consultation'): ?>
                    <p class="card-text">Client: <?php echo htmlspecialchars($details['first_name'] ?? '') . ' ' . htmlspecialchars($details['last_name'] ?? ''); ?></p>
                    <p class="card-text">Email: <?php echo htmlspecialchars($details['email'] ?? ''); ?></p>
                    <p class="card-text">Phone: <?php echo htmlspecialchars($details['phone'] ?? ''); ?></p>
                    <p class="card-text">Date: <?php echo htmlspecialchars($details['appointment_date'] ?? ''); ?></p>
                    <p class="card-text">Time: <?php echo htmlspecialchars($details['time_slot'] ?? ''); ?></p>
                    <p class="card-text">Notes: <?php echo htmlspecialchars($details['notes'] ?? ''); ?></p>
                <?php elseif ($type == 'inquiry'): ?>
                    <h5 class="card-title"><?php echo htmlspecialchars($details['title'] ?? ''); ?></h5>
                    <p class="card-text"><?php echo htmlspecialchars($details['address'] ?? ''); ?></p>
                    <p class="card-text">Message: <?php echo htmlspecialchars($details['message'] ?? ''); ?></p>
                    <p class="card-text">Date: <?php echo htmlspecialchars($details['date'] ?? ''); ?></p>
                    <p class="card-text">From: <?php echo htmlspecialchars($details['sender_email'] ?? ''); ?></p>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <?php include "../footer.php"; ?>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>