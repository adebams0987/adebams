<?php
// Check if the user is logged in and is an agent
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'agent') {
    header('Location: ../login.php');
    exit();
}

// Check if agent_id is set in the session
if (!isset($_SESSION['agent_id'])) {
    die("Agent ID not found in session.");
}

$agent_id = $_SESSION['agent_id'];

// Fetch stats
try {
    // Active Listings
    $activeListingsQuery = "SELECT COUNT(*) AS active_listings FROM Properties WHERE status = 'available' AND agent_id = :agent_id";
    $activeListingsStmt = $pdo->prepare($activeListingsQuery);
    $activeListingsStmt->execute(['agent_id' => $agent_id]);
    $activeListings = $activeListingsStmt->fetch()['active_listings'];

    // Properties Sold
    $propertiesSoldQuery = "SELECT COUNT(*) AS properties_sold FROM Properties WHERE status = 'sold' AND MONTH(updated_at) = MONTH(CURRENT_DATE()) AND agent_id = :agent_id";
    $propertiesSoldStmt = $pdo->prepare($propertiesSoldQuery);
    $propertiesSoldStmt->execute(['agent_id' => $agent_id]);
    $propertiesSold = $propertiesSoldStmt->fetch()['properties_sold'];

    // Query to get the count of rented properties
    $rentedPropertiesQuery = "
    SELECT COUNT(*) 
    FROM Properties p
    WHERE p.agent_id = :agent_id AND p.status = 'rented'";
    $stmt = $pdo->prepare($rentedPropertiesQuery);
    $stmt->execute(['agent_id' => $agent_id]);
    $rentedProperties = $stmt->fetchColumn();

    // New Inquiries
    $newInquiriesQuery = "SELECT COUNT(*) AS new_inquiries FROM contact_messages WHERE created_at >= DATE_SUB(NOW(), INTERVAL 7 DAY) AND agent_id = :agent_id";
    $newInquiriesStmt = $pdo->prepare($newInquiriesQuery);
    $newInquiriesStmt->execute(['agent_id' => $agent_id]);
    $newInquiries = $newInquiriesStmt->fetch()['new_inquiries'];

    // Revenue
    $revenueQuery = "SELECT SUM(price) AS revenue FROM Properties WHERE (status = 'sold' OR status = 'rented') AND MONTH(updated_at) = MONTH(CURRENT_DATE()) AND agent_id = :agent_id";
    $revenueStmt = $pdo->prepare($revenueQuery);
    $revenueStmt->execute(['agent_id' => $agent_id]);
    $revenue = $revenueStmt->fetch()['revenue'] ?? 0;
} catch (PDOException $e) {
    die("Query failed: " . $e->getMessage());
}

try {
    // Query to fetch property details
    $query = "
        SELECT 
            p.property_id, 
            p.title, 
            p.price, 
            p.city, 
            p.state, 
            p.status, 
            p.property_type, 
            MIN(i.image_url) AS image_url,  -- Use MIN to get one image URL per property
            p.created_at
        FROM Properties p
        LEFT JOIN Property_Images i ON p.property_id = i.property_id
        GROUP BY p.property_id, p.title, p.price, p.city, p.state, p.status, p.property_type, p.created_at
        ORDER BY p.created_at DESC
    ";
    $stmt = $pdo->prepare($query);
    $stmt->execute();
    $properties = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    die("Database error: " . $e->getMessage());
}

// Get the filter type from the query string (default to 'All')
$filter = isset($_GET['type']) ? $_GET['type'] : 'All';

try {
    // Base query to fetch properties
    $query = "
        SELECT 
            p.property_id, 
            p.title, 
            p.price, 
            p.city, 
            p.state, 
            p.status, 
            p.property_type, 
            MIN(i.image_url) AS image_url,  -- Use MIN to get one image URL per property
            p.created_at
        FROM Properties p
        LEFT JOIN Property_Images i ON p.property_id = i.property_id
    ";

    // Add WHERE clause if a specific property type is selected
    if ($filter !== 'All') {
        $query .= " WHERE p.property_type = :property_type";
    }

    $query .= " GROUP BY p.property_id, p.title, p.price, p.city, p.state, p.status, p.property_type, p.created_at ORDER BY p.created_at DESC";

    $stmt = $pdo->prepare($query);

    // Bind property type if a filter is applied
    if ($filter !== 'All') {
        $stmt->bindParam(':property_type', $filter);
    }

    $stmt->execute();
    $properties = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    die("Database error: " . $e->getMessage());
}

try {
    // Fetch recent activities related to the agent
    $recentActivitiesQuery = "
        SELECT 
            cm.subject AS activity_title,
            cm.message AS activity_description,
            TIMESTAMPDIFF(MINUTE, cm.created_at, NOW()) AS time_elapsed
        FROM contact_messages cm
        WHERE cm.agent_id = :agent_id
        UNION ALL
        SELECT 
            CONCAT('Property ', p.status) AS activity_title,
            CONCAT(p.title, ' has been ', p.status) AS activity_description,
            TIMESTAMPDIFF(MINUTE, p.updated_at, NOW()) AS time_elapsed
        FROM properties p
        WHERE p.agent_id = :agent_id
        ORDER BY time_elapsed ASC
        LIMIT 5;
    ";

    $recentActivitiesStmt = $pdo->prepare($recentActivitiesQuery);
    $recentActivitiesStmt->bindParam(':agent_id', $agent_id, PDO::PARAM_INT);
    $recentActivitiesStmt->execute();
    $recentActivities = $recentActivitiesStmt->fetchAll(PDO::FETCH_ASSOC);

    // Fetch upcoming appointments for the agent
    $appointmentsQuery = "
    SELECT 
        CONCAT(a.first_name, ' ', a.last_name) AS client_name,
        a.appointment_date,
        a.time_slot,
        IFNULL(p.title, 'Consultation') AS appointment_title,
        IFNULL(p.title, '') AS property_name,
        IF(p.title IS NOT NULL, 'Open House', 'Consultation') AS appointment_type
    FROM appointments a
    LEFT JOIN properties p ON a.property_id = p.property_id
    WHERE a.agent_id = :agent_id AND a.appointment_date >= CURDATE()
    ORDER BY a.appointment_date, a.time_slot ASC
    LIMIT 5;
    ";
    $appointmentsStmt = $pdo->prepare($appointmentsQuery);
    $appointmentsStmt->bindParam(':agent_id', $agent_id, PDO::PARAM_INT);
    $appointmentsStmt->execute();
    $appointments = $appointmentsStmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    die("Database error: " . $e->getMessage());
}
?>