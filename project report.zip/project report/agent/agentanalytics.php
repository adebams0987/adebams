<?php
session_start();
include "../pdo.php";

if (!isset($_SESSION['agent_id'])) {
    die("Agent not logged in");
}

$agent_id = $_SESSION['agent_id'];

try {
    // Query for active listings
    $stmt = $pdo->prepare("
        SELECT COUNT(*) AS active_listings 
        FROM Properties 
        WHERE agent_id = :agent_id AND status = 'available'
    ");
    $stmt->execute(['agent_id' => $agent_id]);
    $activeListings = $stmt->fetch(PDO::FETCH_ASSOC)['active_listings'];

    // Query for property views
    $stmt = $pdo->prepare("
    SELECT COUNT(*) AS total_views
    FROM contact_messages
    WHERE agent_id = :agent_id
    ");
    $stmt->execute(['agent_id' => $agent_id]);
    $totalViews = $stmt->fetch(PDO::FETCH_ASSOC)['total_views'];

    // Query for appointments
    $stmt = $pdo->prepare("
        SELECT COUNT(*) AS total_appointments 
        FROM appointments 
        WHERE agent_id = :agent_id
    ");
    $stmt->execute(['agent_id' => $agent_id]);
    $totalAppointments = $stmt->fetch(PDO::FETCH_ASSOC)['total_appointments'];

    // Query for inquiries
    $stmt = $pdo->prepare("
    SELECT COUNT(*) AS total_inquiries 
    FROM contact_messages 
    WHERE agent_id = :agent_id
    ");
    $stmt->execute(['agent_id' => $agent_id]);
    $totalInquiries = $stmt->fetch(PDO::FETCH_ASSOC)['total_inquiries'];

    // Monthly change metrics (Optional, calculate % increase/decrease)
    // Example: Active listings this month vs. last month
    $stmt = $pdo->prepare("
        SELECT COUNT(*) AS this_month 
        FROM Properties 
        WHERE agent_id = :agent_id AND status = 'available' AND MONTH(created_at) = MONTH(CURRENT_DATE()) 
    ");
    $stmt->execute(['agent_id' => $agent_id]);
    $thisMonthActiveListings = $stmt->fetch(PDO::FETCH_ASSOC)['this_month'];

    $stmt = $pdo->prepare("
        SELECT COUNT(*) AS last_month 
        FROM Properties 
        WHERE agent_id = :agent_id AND status = 'available' AND MONTH(created_at) = MONTH(CURRENT_DATE() - INTERVAL 1 MONTH)
    ");
    $stmt->execute(['agent_id' => $agent_id]);
    $lastMonthActiveListings = $stmt->fetch(PDO::FETCH_ASSOC)['last_month'];

    $activeListingChange = ($lastMonthActiveListings > 0) ? 
        (($thisMonthActiveListings - $lastMonthActiveListings) / $lastMonthActiveListings) * 100 : 0;
} catch (PDOException $e) {
    die("Error fetching metrics: " . $e->getMessage());
}

// Fetch Property Performance Data
$performanceQuery = "
    SELECT MONTH(a.appointment_date) AS month, COUNT(*) AS views 
    FROM Appointments a
    JOIN Properties p ON a.property_id = p.property_id
    WHERE p.agent_id = :agent_id
    GROUP BY MONTH(a.appointment_date)
    
    UNION

    SELECT MONTH(c.created_at) AS month, COUNT(*) AS views
    FROM Contact_Messages c
    JOIN Properties p ON c.property_id = p.property_id
    WHERE c.agent_id = :agent_id AND c.property_id IS NOT NULL
    GROUP BY MONTH(c.created_at)
    
    ORDER BY month
";

$stmt = $pdo->prepare($performanceQuery);
$stmt->execute(['agent_id' => $agent_id]);
$performanceData = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Fetch Listing Types Data
$listingQuery = "
    SELECT status AS type, COUNT(*) AS count 
    FROM Properties 
    WHERE agent_id = :agent_id 
    GROUP BY status";
$stmt = $pdo->prepare($listingQuery);
$stmt->execute(['agent_id' => $agent_id]);
$listingData = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Fetch Recent Activities Data
$recentActivitiesQuery = "
    (SELECT 
        a.appointment_date AS activity_date, 
        p.title AS property, 
        'Open House' AS type, 
        CASE 
            WHEN a.appointment_date <= CURRENT_DATE() THEN 'Pending'
            ELSE 'Scheduled'
        END AS status 
    FROM Appointments a
    LEFT JOIN Properties p ON a.property_id = p.property_id
    WHERE a.agent_id = :agent_id AND a.appointment_type = 'open_house' AND a.appointment_date >= CURRENT_DATE()
)
UNION
(
    SELECT 
        a.appointment_date AS activity_date, 
        NULL AS property, 
        'Consultation' AS type, 
        CASE 
            WHEN a.appointment_date <= CURRENT_DATE() THEN 'Pending'
            ELSE 'Scheduled'
        END AS status 
    FROM Appointments a
    WHERE a.agent_id = :agent_id AND a.appointment_type = 'consultation' AND a.property_id IS NULL AND a.appointment_date >= CURRENT_DATE()
)
UNION
(
    SELECT 
        c.created_at AS activity_date, 
        p.title AS property, 
        'Contact Message' AS type, 
        'New' AS status 
    FROM Contact_Messages c
    LEFT JOIN Properties p ON c.property_id = p.property_id
    WHERE c.agent_id = :agent_id AND c.created_at >= CURRENT_DATE()
)
ORDER BY activity_date DESC
LIMIT 10";
$stmt = $pdo->prepare($recentActivitiesQuery);
$stmt->execute(['agent_id' => $agent_id]);
$recentActivities = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Agent Analytics</title>

    <!-- Favicon Links -->
    <link rel="apple-touch-icon" sizes="180x180" href="../Fonts/apple-touch-icon.png">
    <link rel="icon" type="image/png" sizes="32x32" href="../Fonts/favicon-32x32.png">

    <!-- CSS Links -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://unicons.iconscout.com/release/v4.0.8/css/line.css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css" rel="stylesheet">
    <style>
        :root {
            --primary-bg: #f8f9fa;
            --card-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }
        body {
            background-color: var(--primary-bg);
        }
        .stat-card {
            border-radius: 12px;
            box-shadow: var(--card-shadow);
            transition: transform 0.2s;
        }
        .stat-card:hover {
            transform: translateY(-5px);
        }
        /* .chart-container {
            position: relative;
            height: 400px;
            background: white;
            border-radius: 12px;
            box-shadow: var(--card-shadow);
        } */
        /* Ensure the chart container has a defined height */
        .chart-container {
            position: relative;
            height: 300px; /* Set a fixed height for the charts */
            min-height: 300px; /* Ensure it doesn't shrink below this height */
        }

        canvas {
            display: block;
            width: 100% !important; /* Force the canvas to be responsive */
            height: 100% !important; /* Ensure the canvas scales within its container */
        }
        .card {
            border-radius: 8px;
        }

        .table {
            border-radius: 8px;
        }

        .table th, .table td {
            padding: 12px; /* Enhance padding for better spacing */
        }
    </style>
</head>
<body>

    <?php include "../header.php"; ?>
    
    <div class="container-fluid py-4">
        <!-- Header -->
        <div class="row mb-4">
            <div class="col-12">
                <h2 class="fw-bold">Agent Dashboard</h2>
                <p class="text-muted">Analytics and Performance Overview</p>
            </div>
        </div>
        <div class="row g-4 mb-4">
            <!-- Active Listings -->
            <div class="col-md-3">
                <div class="stat-card card bg-white h-100">
                    <div class="card-body">
                        <div class="d-flex justify-content-between align-items-center">
                            <div>
                                <h6 class="text-muted mb-2">Active Listings</h6>
                                <h3 class="fw-bold mb-0" id="activeListings"><?= $activeListings ?></h3>
                                <small id="activeListingChange" class="text-success">↑ <?= number_format($activeListingChange, 2) ?>% from last month</small>
                            </div>
                            <div class="bg-primary bg-opacity-10 p-3 rounded">
                                <i class="fas fa-home text-primary"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Property Views -->
            <div class="col-md-3">
                <div class="stat-card card bg-white h-100">
                    <div class="card-body">
                        <div class="d-flex justify-content-between align-items-center">
                            <div>
                                <h6 class="text-muted mb-2">Property Views</h6>
                                <h3 class="fw-bold mb-0" id="totalViews"><?= $totalViews ?></h3>
                            </div>
                            <div class="bg-success bg-opacity-10 p-3 rounded">
                                <i class="fas fa-eye text-success"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Appointments -->
            <div class="col-md-3">
                <div class="stat-card card bg-white h-100">
                    <div class="card-body">
                        <div class="d-flex justify-content-between align-items-center">
                            <div>
                                <h6 class="text-muted mb-2">Appointments</h6>
                                <h3 class="fw-bold mb-0" id="totalAppointments"><?= $totalAppointments ?></h3>
                            </div>
                            <div class="bg-warning bg-opacity-10 p-3 rounded">
                                <i class="fas fa-calendar text-warning"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Inquiries -->
            <div class="col-md-3">
                <div class="stat-card card bg-white h-100">
                    <div class="card-body">
                        <div class="d-flex justify-content-between align-items-center">
                            <div>
                                <h6 class="text-muted mb-2">Inquiries</h6>
                                <h3 class="fw-bold mb-0" id="totalInquiries"><?= $totalInquiries ?></h3>
                            </div>
                            <div class="bg-info bg-opacity-10 p-3 rounded">
                                <i class="fas fa-message text-info"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Charts Row -->
        <div class="row g-4 mb-4">
            <div class="col-md-8">
                <div class="chart-container p-4">
                    <h5 class="mb-4">Property Performance</h5>
                    <canvas id="propertyChart"></canvas>
                </div>
            </div>
            <div class="col-md-4">
                <div class="chart-container p-4">
                    <h5 class="mb-4">Listing Types</h5>
                    <canvas id="listingTypesChart"></canvas>
                </div>
            </div>
        </div>

        <table class="table table-bordered table-hover table-striped mt-5">
            <thead class="table-dark">
                <tr>
                    <th>Date</th>
                    <th>Property</th>
                    <th>Type</th>
                    <th>Status</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($recentActivities as $activity): ?>
                    <tr>
                        <td><?= date('M d, Y', strtotime($activity['activity_date'])); ?></td>
                        <td><?= htmlspecialchars($activity['property'] ?: 'No Property'); ?></td>
                        <td><?= ucfirst($activity['type']); ?></td>
                        <td>
                            <span class="badge bg-<?= $activity['status'] === 'Completed' ? 'success' : ($activity['status'] === 'Pending' ? 'warning' : 'info'); ?>">
                                <?= ucfirst($activity['status']); ?>
                            </span>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>

    <?php include "../footer.php"; ?>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/3.9.1/chart.min.js"></script>
    <script>
        // Property Performance Chart Data
        const propertyLabels = <?= json_encode(array_column($performanceData, 'month')); ?>;
        const propertyValues = <?= json_encode(array_column($performanceData, 'views')); ?>;

        const propertyCtx = document.getElementById('propertyChart').getContext('2d');
        new Chart(propertyCtx, {
            type: 'line',
            data: {
                labels: propertyLabels.map(month => new Date(2025, month - 1).toLocaleString('default', { month: 'short' })),
                datasets: [{
                    label: 'Appointments',
                    data: propertyValues,
                    borderColor: '#0d6efd',
                    tension: 0.4
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false
            }
        });

        // Listing Types Chart Data
        const listingLabels = <?= json_encode(array_column($listingData, 'type')); ?>;
        const listingCounts = <?= json_encode(array_column($listingData, 'count')); ?>;

        const listingCtx = document.getElementById('listingTypesChart').getContext('2d');
        new Chart(listingCtx, {
            type: 'pie',
            data: {
                labels: listingLabels,
                datasets: [{
                    label: 'Listings by Type',
                    data: listingCounts,
                    backgroundColor: ['#007bff', '#28a745', '#ffc107', '#dc3545']
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false
            }
        });
    </script>
</body>
</html>
