<?php
session_start();
include '../pdo.php';

// Check if the user is logged in and is an agent
if (!isset($_SESSION['agent_id']) || $_SESSION['role'] !== 'agent') {
    header('Location: ../login.php');
    exit();
}

$agent_id = $_SESSION['agent_id'];
$agent_data = [];

// Fetch agent profile details using agent_id
try {
    $sql = "SELECT u.user_id, u.name, u.email, u.phone_number, a.license_number, a.agency_name, a.profile_picture
            FROM Users u
            INNER JOIN Agents a ON u.user_id = a.user_id
            WHERE a.agent_id = :agent_id";
    $stmt = $pdo->prepare($sql);
    $stmt->execute(['agent_id' => $agent_id]);  // Pass agent_id
    $agent_data = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$agent_data) {
        $_SESSION['error'] = "Agent data not found!";
        header("Location: agent.php");
        exit();
    }
} catch (PDOException $e) {
    die("Error fetching agent data: " . $e->getMessage());
}

// Handle profile update
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = $_POST['name'] ?? $agent_data['name'];
    $email = $_POST['email'] ?? $agent_data['email'];
    $phone = $_POST['phone'] ?? $agent_data['phone_number'];
    $license = $_POST['license_number'] ?? $agent_data['license_number'];
    $agency = $_POST['agency_name'] ?? $agent_data['agency_name'];
    $profile_picture = $agent_data['profile_picture'] ?? "default-profile.png";  // Default image

    // Handle profile picture upload if there is a file
    if (isset($_FILES['profile_picture']) && $_FILES['profile_picture']['error'] === UPLOAD_ERR_OK) {
        $target_dir = "../uploads/profile_pictures/";
        if (!file_exists($target_dir)) {
            mkdir($target_dir, 0777, true); // Ensure parent directories exist
        }

        $file_name = time() . "_" . basename($_FILES['profile_picture']['name']);  // Prevent name conflicts
        $target_file = $target_dir . $file_name;
        $image_file_type = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));

        // Validate image
        if (!getimagesize($_FILES['profile_picture']['tmp_name'])) {
            $_SESSION['error'] = "File is not a valid image.";
        } elseif ($_FILES['profile_picture']['size'] > 5000000) { 
            $_SESSION['error'] = "File is too large.";
        } elseif (!in_array($image_file_type, ['jpg', 'png', 'jpeg', 'gif'])) {
            $_SESSION['error'] = "Only JPG, JPEG, PNG, and GIF files are allowed.";
        } else {
            if (move_uploaded_file($_FILES['profile_picture']['tmp_name'], $target_file)) {
                $profile_picture = $file_name; // Store only filename
            } else {
                $_SESSION['error'] = "There was an error uploading your file.";
            }
        }
    }

    try {
        $pdo->beginTransaction();

        // Update Users table
        $update_user_sql = "UPDATE Users SET name = :name, email = :email, phone_number = :phone WHERE user_id = :user_id";
        $stmt = $pdo->prepare($update_user_sql);
        $stmt->execute([
            'name' => $name,
            'email' => $email,
            'phone' => $phone,
            'user_id' => $agent_data['user_id']  // Use user_id from fetched data
        ]);

        // Update Agents table
        $update_agent_sql = "UPDATE Agents SET license_number = :license, agency_name = :agency, profile_picture = :profile_picture WHERE agent_id = :agent_id";
        $stmt = $pdo->prepare($update_agent_sql);
        $stmt->execute([
            'license' => $license,
            'agency' => $agency,
            'profile_picture' => $profile_picture,
            'agent_id' => $agent_id
        ]);

        $pdo->commit();

        $_SESSION['success'] = "Profile updated successfully!";
        header('Location: agentProfile.php');
        exit();
    } catch (PDOException $e) {
        $pdo->rollBack();
        $_SESSION['error'] = "Failed to update profile: " . $e->getMessage();
    }
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Agent Profile</title>

    <!-- Favicon Links -->
    <link rel="apple-touch-icon" sizes="180x180" href="../Fonts/apple-touch-icon.png">
    <link rel="icon" type="image/png" sizes="32x32" href="../Fonts/favicon-32x32.png">

    <!-- CSS Links -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="../CSS/index.css">
    <link rel="stylesheet" href="https://unicons.iconscout.com/release/v4.0.8/css/line.css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css" rel="stylesheet">

</head>
<body class="d-flex flex-column min-vh-100">
    <?php include "../header.php"; ?>

    <div class="container py-5">
        <!-- Alert Messages -->
        <?php if (isset($_SESSION['success'])): ?>
            <div class="alert alert-success alert-dismissible fade show shadow-sm" role="alert">
                <?= htmlspecialchars($_SESSION['success']); ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                <?php unset($_SESSION['success']); ?>
            </div>
        <?php endif; ?>
        <?php if (isset($_SESSION['error'])): ?>
            <div class="alert alert-danger alert-dismissible fade show shadow-sm" role="alert">
                <?= htmlspecialchars($_SESSION['error']); ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                <?php unset($_SESSION['error']); ?>
            </div>
        <?php endif; ?>
        
        <!-- Profile Card -->
        <div class="bg-white rounded-4 shadow p-4 mb-5 border">
            <div class="row align-items-center g-4">
                <div class="col-md-3 text-center">
                    <div class="position-relative">
                    <img src="../uploads/profile_pictures/<?= htmlspecialchars($agent_data['profile_picture'] ?? 'default-profile.png'); ?>" 
                        class="rounded-circle img-thumbnail shadow-sm" 
                        style="width: 200px; height: 200px; object-fit: cover;" 
                        alt="Agent Profile Picture">
                    </div>
                </div>
                <div class="col-md-9">
                    <h2 class="display-6 fw-bold mb-2"><?= htmlspecialchars($agent_data['name'] ?? ''); ?></h2>
                    <p class="text-muted fs-5 mb-0">
                        <i class="fas fa-building me-2"></i>
                        <?= htmlspecialchars($agent_data['agency_name'] ?? ''); ?>
                    </p>
                </div>
            </div>
        </div>

        <!-- Form Card -->
        <div class="bg-white rounded-4 shadow p-4 border">
            <h3 class="mb-4 fw-bold">Edit Profile</h3>
            <form method="POST" action="agentProfile.php" enctype="multipart/form-data">
                <div class="row g-4">
                    <div class="col-md-6">
                        <div class="form-floating mb-3">
                            <input type="text" class="form-control" id="name" name="name" 
                                value="<?= htmlspecialchars($agent_data['name'] ?? ''); ?>" required>
                            <label for="name">Name</label>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-floating mb-3">
                            <input type="email" class="form-control" id="email" name="email" 
                                value="<?= htmlspecialchars($agent_data['email'] ?? ''); ?>" required>
                            <label for="email">Email</label>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-floating mb-3">
                            <input type="text" class="form-control" id="phone" name="phone" 
                                value="<?= htmlspecialchars($agent_data['phone_number'] ?? ''); ?>">
                            <label for="phone">Phone</label>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-floating mb-3">
                            <input type="text" class="form-control" id="license_number" name="license_number" 
                                value="<?= htmlspecialchars($agent_data['license_number'] ?? ''); ?>">
                            <label for="license_number">License Number</label>
                        </div>
                    </div>
                    <div class="col-12">
                        <div class="form-floating mb-3">
                            <input type="text" class="form-control" id="agency_name" name="agency_name" 
                                value="<?= htmlspecialchars($agent_data['agency_name'] ?? ''); ?>">
                            <label for="agency_name">Agency Name</label>
                        </div>
                    </div>
                    <div class="col-12">
                        <div class="mb-4">
                            <label for="profile_picture" class="form-label">Profile Picture</label>
                            <input type="file" class="form-control form-control-lg" id="profile_picture" name="profile_picture">
                        </div>
                    </div>
                </div>
                
                <div class="d-flex gap-3 justify-content-end mt-4">
                    <a href="agent.php" class="btn btn-light btn-lg px-4">Cancel</a>
                    <button type="submit" class="btn btn-primary btn-lg px-4">Save Changes</button>
                </div>
            </form>
        </div>
    </div>

    <?php include "../footer.php"; ?>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
