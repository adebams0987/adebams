<?php
session_start();
include "../pdo.php";

// Enable error reporting
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Fetch property ID from query parameter (Ensure it's sanitized)
$property_id = isset($_GET['property_id']) ? (int)$_GET['property_id'] : 0; // Assuming property_id is passed as a query parameter
if (!$property_id) {
    die("Property ID is required.");
}

// Debug: Print POST data
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    error_log("POST data received: " . print_r($_POST, true));
}

// Fetch property details
$property_sql = "SELECT * FROM Properties WHERE property_id = :property_id";
$property_stmt = $pdo->prepare($property_sql);
$property_stmt->execute(['property_id' => $property_id]);
$property = $property_stmt->fetch(PDO::FETCH_ASSOC);

if (!$property) {
    $_SESSION['error'] = "Property not found.";
    header("Location: agentProperties.php"); // Redirect to an error page or another page if not found
    exit;
}

// Fetch property images
$image_sql = "SELECT image_id, image_url FROM Property_Images WHERE property_id = :property_id";
$image_stmt = $pdo->prepare($image_sql);
$image_stmt->execute(['property_id' => $property_id]);
$images = $image_stmt->fetchAll(PDO::FETCH_ASSOC);

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['delete_image'])) {
        // Handle image deletion
        $image_id = $_POST['image_id'];
        $deleteSql = "SELECT image_url FROM Property_Images WHERE image_id = :image_id";
        $deleteStmt = $pdo->prepare($deleteSql);
        $deleteStmt->execute(['image_id' => $image_id]);
        $image = $deleteStmt->fetch();

        if ($image) {
            $imagePath = $image['image_url'];
            if (file_exists($imagePath)) {
                if (unlink($imagePath)) {
                    $deleteSql = "DELETE FROM Property_Images WHERE image_id = :image_id";
                    $deleteStmt = $pdo->prepare($deleteSql);
                    $deleteStmt->execute(['image_id' => $image_id]);

                    // Show a success message
                    $_SESSION['success'] = "Image deleted successfully.";
                } else {
                    $_SESSION['error'] = "Failed to delete the image from the server.";
                }
            } else {
                $_SESSION['error'] = "Image file not found on the server.";
            }
        } else {
            $_SESSION['error'] = "Image not found in the database.";
        }

        header("Location: editProperties.php?property_id=$property_id");
        exit;
    } else {
        try {
            // Begin transaction for updating into multiple tables
            $pdo->beginTransaction();

            // Update Properties table
            $sql = "UPDATE Properties 
                    SET title = :title, description = :description, price = :price, 
                        address = :address, city = :city, state = :state, zip_code = :zip_code,
                        property_type = :property_type, listing_type = :listing_type, status = :status, 
                        latitude = :latitude, longitude = :longitude, features = :features
                    WHERE property_id = :property_id";
            
            $stmt = $pdo->prepare($sql);
            $stmt->bindParam(':title', $_POST['title']);
            $stmt->bindParam(':description', $_POST['description']);
            $stmt->bindParam(':price', $_POST['price']);
            $stmt->bindParam(':address', $_POST['address']);
            $stmt->bindParam(':city', $_POST['city']);
            $stmt->bindParam(':state', $_POST['state']);
            $stmt->bindParam(':zip_code', $_POST['zip_code']);
            $stmt->bindParam(':property_type', $_POST['property_type']);
            $stmt->bindParam(':listing_type', $_POST['listing_type']);
            $stmt->bindParam(':status', $_POST['status']);
            $stmt->bindParam(':latitude', $_POST['latitude']);
            $stmt->bindParam(':longitude', $_POST['longitude']);
            $stmt->bindParam(':features', $_POST['features']);
            $stmt->bindParam(':property_id', $property_id);

            $stmt->execute();

            // Handle new image uploads
            if (isset($_FILES['new_images']) && !empty($_FILES['new_images']['name'][0])) {
                $uploadDirectory = "../Images/uploads/"; // Your upload folder path

                // Ensure the upload directory exists and is writable
                if (!is_dir($uploadDirectory)) {
                    mkdir($uploadDirectory, 0777, true);
                }
                if (!is_writable($uploadDirectory)) {
                    $_SESSION['error'] = "Upload directory is not writable.";
                    header("Location: editProperties.php?property_id=$property_id");
                    exit;
                }

                // Debug: Print uploaded files
                echo "<pre>";
                print_r($_FILES['new_images']);
                echo "</pre>";

                // Allowed image types and max file size (e.g., 5MB)
                $allowedMimeTypes = ['image/jpeg', 'image/png'];
                $maxFileSize = 5 * 1024 * 1024; // 5MB

                foreach ($_FILES['new_images']['tmp_name'] as $key => $tmpName) {
                    // Skip if no file was uploaded in this slot
                    if ($_FILES['new_images']['error'][$key] === UPLOAD_ERR_NO_FILE) {
                        continue;
                    }

                    $fileName = $_FILES['new_images']['name'][$key];
                    $fileTmpPath = $_FILES['new_images']['tmp_name'][$key];
                    $fileSize = $_FILES['new_images']['size'][$key];

                    // Use finfo_open() to get the MIME type
                    $finfo = finfo_open(FILEINFO_MIME_TYPE);
                    $fileMimeType = finfo_file($finfo, $fileTmpPath);
                    finfo_close($finfo);

                    // Check if the file type is allowed
                    if (!in_array($fileMimeType, $allowedMimeTypes)) {
                        $_SESSION['error'] = "Invalid file type. Only JPEG and PNG images are allowed.";
                        header("Location: editProperties.php?property_id=$property_id");
                        exit;
                    }

                    // Check if the file size is within the limit
                    if ($fileSize > $maxFileSize) {
                        $_SESSION['error'] = "File size exceeds the maximum limit of 5MB.";
                        header("Location: editProperties.php?property_id=$property_id");
                        exit;
                    }

                    // Handle file upload errors
                    if ($_FILES['new_images']['error'][$key] !== UPLOAD_ERR_OK) {
                        $_SESSION['error'] = "Error uploading file: " . $_FILES['new_images']['error'][$key];
                        header("Location: editProperties.php?property_id=$property_id");
                        exit;
                    }

                    // Generate a unique name for each file
                    $fileDestination = $uploadDirectory . uniqid() . '_' . basename($fileName);

                    // Move the file to the desired location
                    if (move_uploaded_file($fileTmpPath, $fileDestination)) {
                        // Insert the image URL into the Property_Images table
                        $sql = "INSERT INTO Property_Images (property_id, image_url) VALUES (:property_id, :image_url)";
                        $stmt = $pdo->prepare($sql);
                        $stmt->bindParam(':property_id', $property_id);
                        $stmt->bindParam(':image_url', $fileDestination);
                        if (!$stmt->execute()) {
                            $_SESSION['error'] = "Failed to insert image into the database.";
                            header("Location: editProperties.php?property_id=$property_id");
                            exit;
                        }
                    } else {
                        $_SESSION['error'] = "Failed to move uploaded file.";
                        header("Location: editProperties.php?property_id=$property_id");
                        exit;
                    }
                }
            }

            // Commit the transaction
            $pdo->commit();

            // Set success message and redirect
            $_SESSION['success'] = "Property updated successfully!";
            header("Location: agentProperties.php");
            exit;

        } catch (Exception $e) {
            // Rollback if something goes wrong
            $pdo->rollBack();

            // Set error message and redirect
            $_SESSION['error'] = "Error: " . $e->getMessage();
            header("Location: editProperties.php?property_id=$property_id");
            exit;
        }
    }
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Property</title>

    <!-- Favicon Links -->
    <link rel="apple-touch-icon" sizes="180x180" href="../Fonts/apple-touch-icon.png">
    <link rel="icon" type="image/png" sizes="32x32" href="../Fonts/favicon-32x32.png">

    <!-- CSS Links -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://unicons.iconscout.com/release/v4.0.8/css/line.css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css" rel="stylesheet">

    <style>
        body {
            background-color: #f8f9fa;
        }
        .edit-property-header {
            background: linear-gradient(135deg, #0d6efd 0%, #0099ff 100%);
            color: white;
            padding: 2rem 0;
            margin-bottom: 2rem;
        }
        .form-card {
            border-radius: 15px;
            box-shadow: 0 0 20px rgba(0,0,0,0.1);
        }
        .image-preview {
            width: 150px;
            height: 150px;
            object-fit: cover;
            border-radius: 10px;
            margin: 5px;
        }
        .upload-area {
            border: 2px dashed #dee2e6;
            border-radius: 10px;
            padding: 20px;
            text-align: center;
            background: #f8f9fa;
        }
    </style>
</head>
<body>
    <?php include "../header.php"; ?>

    <?php
        if (!empty($_SESSION['error'])) {
            echo '<div class="alert alert-danger" role="alert">';
            echo htmlspecialchars($_SESSION['error']);
            echo '</div>';
            unset($_SESSION['error']); // Clear the message after displaying it
        }

        if (!empty($_SESSION['success'])) {
            echo '<div class="alert alert-success" role="alert">';
            echo htmlspecialchars($_SESSION['success']);
            echo '</div>';
            unset($_SESSION['success']); // Clear the message after displaying it
        }
    ?>

    <div class="edit-property-header">
        <div class="container">
            <h1><i class="fas fa-home me-2"></i>Edit Property</h1>
            <p class="mb-0">Update property information and details</p>
        </div>
    </div>

    <div class="container mb-5">
        <div class="card form-card">
            <div class="card-body p-4">
                <form method="POST" action="editProperties.php?property_id=<?= htmlspecialchars($property['property_id']) ?>" enctype="multipart/form-data">
                    <input type="hidden" name="property_id" value="<?= htmlspecialchars($property['property_id']) ?>">

                    <!-- Basic Information -->
                    <div class="row mb-4">
                        <div class="col-12">
                            <h4 class="mb-3">Basic Information</h4>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Property Title</label>
                            <input type="text" class="form-control" name="title" value="<?= htmlspecialchars($property['title']) ?>">
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Price</label>
                            <div class="input-group">
                                <span class="input-group-text">$</span>
                                <input type="number" class="form-control" name="price" value="<?= htmlspecialchars($property['price']) ?>">
                            </div>
                        </div>
                    </div>

                    <!-- Property Details -->
                    <div class="row mb-4">
                        <div class="col-12">
                            <h4 class="mb-3">Property Details</h4>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Property Type</label>
                            <select class="form-select" name="property_type">
                                <option value="residential" <?= $property['property_type'] == 'residential' ? 'selected' : '' ?>>Residential</option>
                                <option value="commercial" <?= $property['property_type'] == 'commercial' ? 'selected' : '' ?>>Commercial</option>
                            </select>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Listing Type</label>
                            <select class="form-select" name="listing_type">
                                <option value="sale" <?= $property['listing_type'] == 'sale' ? 'selected' : '' ?>>For Sale</option>
                                <option value="rent" <?= $property['listing_type'] == 'rent' ? 'selected' : '' ?>>For Rent</option>
                            </select>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Status</label>
                            <select class="form-select" name="status">
                                <option value="available" <?= $property['status'] == 'available' ? 'selected' : '' ?>>Available</option>
                                <option value="sold" <?= $property['status'] == 'sold' ? 'selected' : '' ?>>Sold</option>
                                <option value="rented" <?= $property['status'] == 'rented' ? 'selected' : '' ?>>Rented</option>
                            </select>
                        </div>
                    </div>

                    <!-- Location -->
                    <div class="row mb-4">
                        <div class="col-12">
                            <h4 class="mb-3">Location</h4>
                        </div>
                        <div class="col-12 mb-3">
                            <label class="form-label">Address</label>
                            <input type="text" class="form-control" name="address" value="<?= htmlspecialchars($property['address']) ?>">
                        </div>
                        <div class="col-md-4 mb-3">
                            <label class="form-label">City</label>
                            <input type="text" class="form-control" name="city" value="<?= htmlspecialchars($property['city']) ?>">
                        </div>
                        <div class="col-md-4 mb-3">
                            <label class="form-label">State</label>
                            <input type="text" class="form-control" name="state" value="<?= htmlspecialchars($property['state']) ?>">
                        </div>
                        <div class="col-md-4 mb-3">
                            <label class="form-label">ZIP Code</label>
                            <input type="text" class="form-control" name="zip_code" value="<?= htmlspecialchars($property['zip_code']) ?>">
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Latitude</label>
                            <input type="text" class="form-control" name="latitude" value="<?= htmlspecialchars($property['latitude']) ?>">
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Longitude</label>
                            <input type="text" class="form-control" name="longitude" value="<?= htmlspecialchars($property['longitude']) ?>">
                        </div>
                    </div>

                    <!-- Description -->
                    <div class="row mb-4">
                        <div class="col-12">
                            <h4 class="mb-3">Description & Features</h4>
                        </div>
                        <div class="col-12 mb-3">
                            <label class="form-label">Property Description</label>
                            <textarea class="form-control" name="description" rows="4"><?= htmlspecialchars($property['description']) ?></textarea>
                        </div>
                        <div class="col-12 mb-3">
                            <label class="form-label">Features</label>
                            <textarea class="form-control" name="features" rows="3"><?= htmlspecialchars($property['features']) ?></textarea>
                        </div>
                    </div>

                    <!-- Images Section -->
                    <div class="row mb-4">
                        <div class="col-12">
                            <h4 class="mb-3">Current Images</h4>
                        </div>
                        <div class="col-12 d-flex flex-wrap">
                            <?php foreach ($images as $image): ?>
                                <div class="image-preview-container position-relative me-2 mb-2">
                                    <img src="<?= htmlspecialchars($image['image_url']) ?>" alt="Property" class="image-preview">
                                    <button type="button" class="btn btn-sm btn-danger position-absolute top-0 end-0 delete-image" 
                                            data-image-id="<?= $image['image_id'] ?>">
                                        <i class="fas fa-trash"></i>
                                    </button>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    </div>
                    
                    <!-- New Images Upload -->
                    <div class="row mb-4">
                        <div class="col-12">
                            <h4 class="mb-3">Upload New Images</h4>
                        </div>
                        <div class="col-12">
                            <div class="upload-area">
                                <input type="file" class="form-control" name="new_images[]" multiple accept="image/*">
                                <p class="text-muted mt-2">
                                    <i class="fas fa-cloud-upload-alt fa-2x mb-2"></i><br>
                                    Drag and drop images here or click to upload
                                </p>
                            </div>
                        </div>
                    </div>

                    <!-- Action Buttons -->
                    <div class="row">
                        <div class="col-12 d-flex justify-content-end gap-2">
                            <a href="agentProperties.php" class="btn btn-outline-secondary">Cancel</a>
                            <button type="submit" class="btn btn-primary">Save Changes</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <?php include "../footer.php"; ?>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
    document.addEventListener('DOMContentLoaded', function() {
        // Main form submission logging
        const form = document.querySelector('form');
        form.addEventListener('submit', function(e) {
            console.log('Form submission attempted');
        });

        // Handle image deletion
        document.querySelectorAll('.delete-image').forEach(button => {
            button.addEventListener('click', function() {
                const imageId = this.dataset.imageId;
                const formData = new FormData();
                formData.append('delete_image', '1');
                formData.append('image_id', imageId);

                fetch('editProperties.php?property_id=<?= $property_id ?>', {
                    method: 'POST',
                    body: formData
                })
                .then(response => response.text())
                .then(() => {
                    // Reload the page to show the updated images
                    window.location.reload();
                })
                .catch(error => {
                    console.error('Error:', error);
                });
            });
        });
    });
    </script>
</body>
</html>