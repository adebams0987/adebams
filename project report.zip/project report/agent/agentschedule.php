<?php
session_start();
include "../pdo.php";

// Assuming agent_id is stored in session after login
if (!isset($_SESSION['agent_id'])) {
    header('Location: ../login.php');
    exit();
}

$agent_id = $_SESSION['agent_id'];  // Adjust based on your session setup

// Query for appointments specific to the logged-in agent
$sql = "SELECT a.id, a.first_name, a.last_name, a.email, a.phone, a.appointment_date, a.time_slot, a.appointment_type, a.notes,
               CASE
                   WHEN a.appointment_type = 'openhouse' AND p.property_id IS NOT NULL THEN p.title
                   ELSE NULL
               END AS title,
               CASE
                   WHEN a.appointment_type = 'openhouse' AND p.property_id IS NOT NULL THEN p.address
                   ELSE NULL
               END AS address,
               CASE
                   WHEN a.appointment_type = 'openhouse' AND p.property_id IS NOT NULL THEN p.city
                   ELSE NULL
               END AS city,
               CASE
                   WHEN a.appointment_type = 'openhouse' AND p.property_id IS NOT NULL THEN p.state
                   ELSE NULL
               END AS state,
               CASE
                   WHEN a.appointment_type = 'openhouse' AND p.property_id IS NOT NULL THEN pi.image_url
                   ELSE NULL
               END AS image_url
        FROM appointments a
        LEFT JOIN properties p ON a.property_id = p.property_id
        LEFT JOIN property_images pi ON p.property_id = pi.property_id
        WHERE a.agent_id = :agent_id"; // Filter by agent_id

$stmt = $pdo->prepare($sql);
$stmt->execute(['agent_id' => $agent_id]);
$appointments = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Query to fetch inquiries specific to the logged-in agent
$sql = "SELECT cm.id, cm.email AS sender_email, cm.message, cm.created_at AS date, 
               p.title, p.address
        FROM contact_messages cm
        LEFT JOIN properties p ON cm.property_id = p.property_id
        WHERE cm.agent_id = :agent_id
        ORDER BY cm.created_at DESC";  // Adjust the ORDER BY if you need

$stmt = $pdo->prepare($sql);
$stmt->execute(['agent_id' => $agent_id]);
$inquiries = $stmt->fetchAll(PDO::FETCH_ASSOC);

?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Agent Schedule</title>

    <!-- Favicon Links -->
    <link rel="apple-touch-icon" sizes="180x180" href="../Fonts/apple-touch-icon.png">
    <link rel="icon" type="image/png" sizes="32x32" href="../Fonts/favicon-32x32.png">

    <!-- CSS Links -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://unicons.iconscout.com/release/v4.0.8/css/line.css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css" rel="stylesheet">
    <style>
        body {
            font-family: 'Roboto', sans-serif;
        }
        .profile-picture {
            width: 50px;
            height: 50px;
            border-radius: 50%;
        }
        .card-header {
            background-color: #f8f9fa;
        }
        .card-body {
            padding: 1rem;
        }
        .card {
            margin-bottom: 1rem;
        }
    </style>
</head>

<body>
    <?php include "../header.php"; ?>

    <div class="container mt-5">
        <!-- Open Houses Section -->
        <div class="card mb-4">
            <div class="card-header">
                <h5>Open Houses</h5>
            </div>
            <div class="card-body">
                <div class="row">
                    <?php
                    // Filter appointments for open houses with valid property details
                    $openHouses = array_filter($appointments, function($appointment) {
                        return $appointment['appointment_type'] == 'openhouse' && !empty($appointment['title']);
                    });

                    // Check if there are any open houses
                    if (empty($openHouses)): ?>
                        <div class="col-12">
                            <p class="text-center">No open houses available at the moment.</p>
                        </div>
                    <?php else: ?>
                        <?php foreach ($openHouses as $appointment): ?>
                            <div class="col-md-4">
                                <div class="card" onclick="window.location.href='details.php?type=openhouse&id=<?php echo $appointment['id']; ?>'">
                                    <img alt="Open House Image" class="card-img-top" height="200" src="<?php echo $appointment['image_url'] ?? 'default_image.jpg'; ?>" width="300"/>
                                    <div class="card-body">
                                        <h5 class="card-title"><?php echo $appointment['title']; ?></h5>
                                        <p class="card-text"><?php echo $appointment['address'] . ', ' . $appointment['city'] . ', ' . $appointment['state']; ?></p>
                                        <p class="card-text">
                                            <small class="text-muted">Open House: <?php echo $appointment['appointment_date']; ?> at <?php echo $appointment['time_slot']; ?></small>
                                        </p>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <!-- Consultation Section -->
        <div class="card mb-4">
            <div class="card-header">
                <h5>Consultations</h5>
            </div>
            <div class="card-body">
                <table class="table table-striped">
                    <thead>
                        <tr>
                            <th scope="col">Client</th>
                            <th scope="col">Email</th>
                            <th scope="col">Phone</th>
                            <th scope="col">Date</th>
                            <th scope="col">Time</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($appointments as $appointment): ?>
                            <?php if ($appointment['appointment_type'] == 'consultation'): ?>
                                <tr onclick="window.location.href='details.php?type=consultation&id=<?php echo $appointment['id']; ?>'">
                                    <td><?php echo $appointment['first_name'] . ' ' . $appointment['last_name']; ?></td>
                                    <td><?php echo $appointment['email']; ?></td>
                                    <td><?php echo $appointment['phone']; ?></td>
                                    <td><?php echo $appointment['appointment_date']; ?></td>
                                    <td><?php echo $appointment['time_slot']; ?></td>
                                </tr>
                            <?php endif; ?>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>

        <!-- Inquiries Section -->
        <div class="card mb-4">
            <div class="card-header">
                <h5>Inquiries</h5>
            </div>
            <div class="card-body">
                <div class="list-group">
                    <?php if (empty($inquiries)): ?>
                        <p>No inquiries found.</p>
                    <?php else: ?>
                        <?php foreach ($inquiries as $inquiry): ?>
                            <a class="list-group-item list-group-item-action" href="details.php?type=inquiry&id=<?php echo $inquiry['id']; ?>">
                                <div class="d-flex w-100 justify-content-between">
                                    <?php 
                                        // Check if property title and address are available
                                        if ($inquiry['title'] && $inquiry['address']) {
                                            $property_info = "Inquiry about " . htmlspecialchars($inquiry['title']) . " at " . htmlspecialchars($inquiry['address']);
                                        } else {
                                            $property_info = "General Inquiry (No Property Specified)";
                                        }
                                    ?>
                                    <h5 class="mb-1"><?php echo $property_info; ?></h5>
                                    <small><?php echo htmlspecialchars($inquiry['date']); ?></small>
                                </div>
                                <p class="mb-1"><?php echo htmlspecialchars($inquiry['message']); ?></p>
                                <small>From: <?php echo htmlspecialchars($inquiry['sender_email']); ?></small>
                            </a>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>

    <?php include "../footer.php"; ?>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>