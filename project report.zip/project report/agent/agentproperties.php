<?php
session_start();
include "../pdo.php";

// Ensure the agent's ID is available in the session
if (!isset($_SESSION['agent_id'])) {
    die("Agent ID not found in session.");
}

$agent_id = $_SESSION['agent_id'];
$propertiesPerPage = 5;

// Calculate the total number of properties for the agent
try {
    $totalPropertiesQuery = "SELECT COUNT(DISTINCT p.property_id) FROM Properties p WHERE p.agent_id = :agent_id";
    $totalPropertiesStmt = $pdo->prepare($totalPropertiesQuery);
    $totalPropertiesStmt->execute(['agent_id' => $agent_id]);
    $totalProperties = $totalPropertiesStmt->fetchColumn();
} catch (PDOException $e) {
    echo "Error: " . $e->getMessage();
    exit();
}

// Determine the current page and calculate the offset
$currentPage = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$offset = ($currentPage - 1) * $propertiesPerPage;

// Fetch properties for the current page
try {
    $sql = "SELECT p.property_id, p.title, p.price, p.address, p.city, p.state, p.features, p.status, MIN(pi.image_url) AS image_url
            FROM Properties p
            LEFT JOIN Property_Images pi ON p.property_id = pi.property_id
            WHERE p.agent_id = :agent_id
            GROUP BY p.property_id, p.title, p.price, p.address, p.city, p.state, p.status, p.features
            LIMIT :limit OFFSET :offset";
    $stmt = $pdo->prepare($sql);
    $stmt->bindParam(':agent_id', $agent_id, PDO::PARAM_INT);
    $stmt->bindParam(':limit', $propertiesPerPage, PDO::PARAM_INT);
    $stmt->bindParam(':offset', $offset, PDO::PARAM_INT);
    $stmt->execute();
    $properties = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    echo "Error: " . $e->getMessage();
    exit();
}

// Calculate the total number of pages
$totalPages = ceil($totalProperties / $propertiesPerPage);
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Agent Properties</title>

    <!-- Favicon Links -->
    <link rel="apple-touch-icon" sizes="180x180" href="../Fonts/apple-touch-icon.png">
    <link rel="icon" type="image/png" sizes="32x32" href="../Fonts/favicon-32x32.png">

    <!-- CSS Links -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://unicons.iconscout.com/release/v4.0.8/css/line.css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css" rel="stylesheet">

    <style>
        body {
            font-family: 'Inter', system-ui, -apple-system, sans-serif;
            color: var(--text-color);
            line-height: 1.7;
        }

        h2 {
            font-weight: 700;
            color: #333;
        }

        .card {
            transition: transform 0.3s ease, box-shadow 0.3s ease;
            border: none;
            border-radius: 15px;
        }

        .card:hover {
            transform: translateY(-10px);
            box-shadow: 0 8px 20px rgba(0, 0, 0, 0.1);
        }

        .card-img-top {
            width: 100%;  
            height: auto;
            object-fit: contain; 
            border-top-left-radius: 15px;
            border-top-right-radius: 15px;
        }

        .carousel-inner img {
            width: 100%;  /* Makes the image fill the width of the container (card) */
            height: 100%; /* Makes the image fill the height of the container */
            object-fit: cover; /* Ensures the image covers the container without stretching */
            max-width: 6016px; /* Limits the width to 6016px */
            max-height: 3384px; /* Limits the height to 3384px */
        }

        .badge {
            font-size: 0.875rem;
            padding: 0.5rem 0.75rem;
            border-radius: 0.5rem;
        }

        .btn {
            text-transform: uppercase;
            font-weight: 600;
            border-radius: 50px;
            padding: 10px 25px;
            transition: all 0.3s ease;
        }

        .btn-sm {
            padding: 8px 20px;
        }

        .btn:hover {
            transform: scale(1.05);
        }

        .card-title {
            font-weight: 600;
            font-size: 1.1rem;
        }

        .card-text {
            font-size: 0.9rem;
            color: #6c757d;
        }

        .feature-badge {
            background-color: #f8f9fa;
            color: #333;
            padding: 8px 15px;
            border-radius: 50px;
            font-size: 0.875rem;
            transition: all 0.3s ease;
        }

        .feature-badge:hover {
            background-color: #007bff;
            color: white;
        }

        .add-property-btn {
            background: linear-gradient(135deg, #007bff, #5c7cb8);
            border: none;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
        }

        .add-property-btn:hover {
            background: linear-gradient(135deg, #0056b3, #4a6491);
            transform: scale(1.05);
        }
    </style>
</head>
<body>
    <?php include "../header.php"; ?>

    <?php
        if (!empty($_SESSION['error'])) {
            echo '<div class="alert alert-danger" role="alert">';
            echo htmlspecialchars($_SESSION['error']);
            echo '</div>';
            unset($_SESSION['error']); // Clear the message after displaying it
        }

        if (!empty($_SESSION['success'])) {
            echo '<div class="alert alert-success" role="alert">';
            echo htmlspecialchars($_SESSION['success']);
            echo '</div>';
            unset($_SESSION['success']); // Clear the message after displaying it
        }
    ?>

    <div class="container mt-5">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h2 class="mb-0">My Properties</h2>
            <a href="addProperties.php" class="btn btn-primary add-property-btn">
                <i class="fas fa-plus me-2"></i>Add New Property
            </a>
        </div>

        <div class="row g-4">
            <?php if (empty($properties)): ?>
                <div class="col-12 text-center">
                    <div class="alert alert-warning" role="alert">
                        <h4 class="alert-heading">No Properties Found</h4>
                        <p>You haven't added any properties yet. Click the add new property button to add your first property.</p>
                        <!-- <a href="addProperties.php" class="btn btn-primary add-property-btn">
                            <i class="fas fa-plus me-2"></i>Add New Property
                        </a> -->
                    </div>
                </div>
            <?php else: ?>
                <?php foreach ($properties as $property): ?>
                <div class="col-12">
                    <div class="card shadow-sm h-100">
                        <!-- Fetch all images for the current property -->
                        <?php
                        $query = "SELECT * FROM Property_Images WHERE property_id = :property_id";
                        $stmt = $pdo->prepare($query);
                        $stmt->bindParam(':property_id', $property['property_id']);
                        $stmt->execute();
                        $images = $stmt->fetchAll();
                        ?>

                        <!-- Bootstrap Carousel -->
                        <div id="propertyCarousel-<?php echo $property['property_id']; ?>" class="carousel slide" data-bs-ride="carousel">
                            <div class="carousel-inner">
                                <?php foreach ($images as $index => $image): ?>
                                <div class="carousel-item <?php echo ($index === 0) ? 'active' : ''; ?>">
                                    <img src="<?php echo $image['image_url'] ?: '/api/placeholder/400/300'; ?>" class="d-block w-100" alt="Property Image">
                                </div>
                                <?php endforeach; ?>
                            </div>
                            <button class="carousel-control-prev" type="button" data-bs-target="#propertyCarousel-<?php echo $property['property_id']; ?>" data-bs-slide="prev">
                                <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                                <span class="visually-hidden">Previous</span>
                            </button>
                            <button class="carousel-control-next" type="button" data-bs-target="#propertyCarousel-<?php echo $property['property_id']; ?>" data-bs-slide="next">
                                <span class="carousel-control-next-icon" aria-hidden="true"></span>
                                <span class="visually-hidden">Next</span>
                            </button>
                        </div>
                        <div class="card-body p-4">
                            <div class="d-flex justify-content-between align-items-center mb-3">
                                <h5 class="card-title mb-0"><?php echo htmlspecialchars($property['title']); ?></h5>
                                <span class="badge <?php echo ($property['status'] == 'sold' ? 'bg-danger' : ($property['status'] == 'rented' ? 'bg-warning' : 'bg-success')); ?>">
                                    <?php echo ucfirst($property['status']); ?>
                                </span>
                            </div>
                            <p class="text-primary fw-bold fs-4 mb-2">$<?php echo number_format($property['price'], 2); ?></p>
                            <p class="card-text mb-3">
                                <i class="fas fa-map-marker-alt me-2 text-primary"></i>
                                <?php echo htmlspecialchars($property['address']) . ", " . htmlspecialchars($property['city']) . ", " . htmlspecialchars($property['state']); ?>
                            </p>
                            <div class="d-flex gap-2 flex-wrap mb-4">
                                <?php
                                $features = explode(',', $property['features'] ?? '');
                                foreach ($features as $feature) {
                                    if (trim($feature)) {
                                        echo '<span class="feature-badge">' . htmlspecialchars(trim($feature)) . '</span>';
                                    }
                                }
                                ?>
                            </div>
                            <div class="d-flex justify-content-between mt-auto">
                                <a href="editProperties.php?property_id=<?php echo $property['property_id']; ?>" class="btn btn-outline-primary btn-sm">
                                    <i class="fas fa-edit me-2"></i>Edit
                                </a>
                                <a href="deleteProperties.php?property_id=<?php echo $property['property_id']; ?>" class="btn btn-outline-danger btn-sm">
                                    <i class="fas fa-trash me-2"></i>Delete
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
                <?php endforeach; ?>
                <?php endif; ?>
            </div>

        <!-- Pagination -->
        <nav aria-label="Page navigation example">
            <ul class="pagination justify-content-center mt-4">
                <?php if ($currentPage > 1): ?>
                    <li class="page-item">
                        <a class="page-link" href="?page=<?php echo $currentPage - 1; ?>" aria-label="Previous">
                            <span aria-hidden="true">&laquo;</span>
                        </a>
                    </li>
                <?php endif; ?>
                <?php for ($i = 1; $i <= $totalPages; $i++): ?>
                    <li class="page-item <?php echo ($i == $currentPage) ? 'active' : ''; ?>">
                        <a class="page-link" href="?page=<?php echo $i; ?>"><?php echo $i; ?></a>
                    </li>
                <?php endfor; ?>
                <?php if ($currentPage < $totalPages): ?>
                    <li class="page-item">
                        <a class="page-link" href="?page=<?php echo $currentPage + 1; ?>" aria-label="Next">
                            <span aria-hidden="true">&raquo;</span>
                        </a>
                    </li>
                <?php endif; ?>
            </ul>
        </nav>
    </div>

    <?php include "../footer.php"; ?>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    
</body>
</html>
