<?php
require '../pdo.php';

if (isset($_GET['agent_id'])) {
    $agent_id = intval($_GET['agent_id']); 

    try {
        // Begin transaction
        $pdo->beginTransaction();

        // Get the user_id of the agent before deletion
        $stmt = $pdo->prepare("SELECT user_id FROM Agents WHERE agent_id = ?");
        $stmt->execute([$agent_id]);
        $user = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($user) {
            // Delete the user (triggers cascade delete on agent)
            $stmt = $pdo->prepare("DELETE FROM Users WHERE user_id = ?");
            $stmt->execute([$user['user_id']]);

            // Commit transaction
            $pdo->commit();

            // Redirect with success message
            header("Location: manageAgents.php?success=Agent deleted successfully");
            exit;
        } else {
            throw new Exception("Agent not found.");
        }
    } catch (Exception $e) {
        $pdo->rollBack();
        header("Location: manageAgents.php?error=" . urlencode($e->getMessage()));
        exit;
    }
} else {
    header("Location: manageAgents.php?error=Invalid request");
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <script>
        function confirmDelete(agentId) {
            if (confirm("Are you sure you want to delete this agent? This action cannot be undone.")) {
                window.location.href = `deleteAgent.php?agent_id=${agentId}`;
            }
        }
    </script> 
</body>
</html>