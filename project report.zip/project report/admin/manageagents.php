<?php
session_start();
include "../pdo.php";

// Check if the user is logged in and is an agent
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header('Location: ../login.php');
    exit();
}

// Check if agent_id is set in the session
if (!isset($_SESSION['admin_id'])) {
    die("Admin ID not found in session.");
}
$admin_id = $_SESSION['admin_id'];

$limit = 20; // Agents per page
$page = isset($_GET['page']) ? (int) $_GET['page'] : 1;
$offset = ($page - 1) * $limit;

try {
    $stmt = $pdo->prepare("
    SELECT 
    a.agent_id, 
    u.name, 
    u.email, 
    u.phone_number, 
    a.license_number, 
    a.agency_name, 
    a.profile_picture, 
    u.created_at,
    COALESCE(p.listings_count, 0) AS active_listings
FROM Agents a
JOIN Users u ON a.user_id = u.user_id
LEFT JOIN (
    SELECT agent_id, COUNT(*) AS listings_count 
    FROM Properties 
    WHERE status = 'available' 
    GROUP BY agent_id
) p ON a.agent_id = p.agent_id
LIMIT :limit OFFSET :offset");
    $stmt->bindParam(':limit', $limit, PDO::PARAM_INT);
    $stmt->bindParam(':offset', $offset, PDO::PARAM_INT);
    $stmt->execute();
    $agents = $stmt->fetchAll(PDO::FETCH_ASSOC);

     // Total Agents
     $stmt = $pdo->query("SELECT COUNT(*) AS total_agents FROM Agents");
     $total_agents = $stmt->fetch(PDO::FETCH_ASSOC)['total_agents'];
 
     // Active Listings
     $stmt = $pdo->query("SELECT COUNT(*) AS active_listings FROM Properties WHERE status = 'available'");
     $active_listings = $stmt->fetch(PDO::FETCH_ASSOC)['active_listings'];
 
     // Sales This Month
     $stmt = $pdo->query("
        SELECT COUNT(*) AS this_month_sales 
        FROM Properties 
        WHERE status = 'sold' 
        AND MONTH(updated_at) = MONTH(CURRENT_DATE()) 
        AND YEAR(updated_at) = YEAR(CURRENT_DATE());
    ");
    $this_month_sales = $stmt->fetch(PDO::FETCH_ASSOC)['this_month_sales'];

    $stmt = $pdo->query("
        SELECT COUNT(*) AS top_performers_count
        FROM (
            SELECT agent_id, SUM(price) AS total_revenue
            FROM Properties
            WHERE status IN ('sold', 'rented')
            GROUP BY agent_id
            HAVING total_revenue >= 1000000
        ) AS top_performers;
    ");
    $top_performers_count = $stmt->fetch(PDO::FETCH_ASSOC)['top_performers_count'];

} catch (PDOException $e) {
    die("Database error: " . $e->getMessage());
}
$totalPages = ceil($total_agents / $limit);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>

    <!-- Favicon Links -->
    <link rel="apple-touch-icon" sizes="180x180" href="../Fonts/apple-touch-icon.png">
    <link rel="icon" type="image/png" sizes="32x32" href="../Fonts/favicon-32x32.png">

    <!-- CSS Links -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://unicons.iconscout.com/release/v4.0.8/css/line.css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css" rel="stylesheet">
    
    <style>
        body {
            font-family: 'Poppins', sans-serif;
            background-color: #f8f9fc;
        }
        .card-custom {
            border-radius: 12px;
            transition: 0.3s;
        }
        .card-custom:hover {
            box-shadow: 0px 4px 12px rgba(0, 0, 0, 0.1);
        }
        .table-hover tbody tr:hover {
            background-color: #f1f3f5;
        }
    </style>
</head>
<body class="d-flex flex-column min-vh-100">
    <?php include "../header.php"; ?>

    <div class="container py-4">
        <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
            <h1 class="h2">Manage Agents</h2>
            <div class="btn-toolbar mb-2 mb-md-0">
                <div class="btn-group me-2">
                    <button type="button" class="btn btn-sm btn-outline-primary">Export</button>
                </div>
            </div>
        </div>

        <div class="row mb-4">
            <div class="col-md-3">
                <div class="card card-custom border-0 shadow-sm text-center p-3">
                    <i class="fas fa-user-tie fa-2x text-primary mb-2"></i>
                    <h5>Total Agents</h5>
                    <h3><?= $total_agents ?></h3>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card card-custom border-0 shadow-sm text-center p-3">
                    <i class="fas fa-home fa-2x text-success mb-2"></i>
                    <h5>Active Listings</h5>
                    <h3><?= $active_listings ?></h3>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card card-custom border-0 shadow-sm text-center p-3">
                    <i class="fas fa-chart-line fa-2x text-info mb-2"></i>
                    <h5>This Month Sales</h5>
                    <h3><?= $this_month_sales ?></h3>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card card-custom border-0 shadow-sm text-center p-3">
                    <i class="fas fa-star fa-2x text-warning mb-2"></i>
                    <h5>Top Performers</h5>
                    <h3><?= $top_performers_count ?></h3>
                </div>
            </div>
        </div>


        <div class="card shadow mb-4">
            <div class="card-header py-3 d-flex justify-content-between align-items-center">
                <div class="col-md-6">
                    <div class="input-group">
                        <span class="input-group-text bg-white border-end-0">
                            <i class="fas fa-search text-muted"></i>
                        </span>
                        <input type="text" class="form-control border-start-0" id="searchAgent" placeholder="Search...">
                    </div>
                </div>
                <div class="col-md-6 text-md-end">
                <div class="dropdown">
                        <button class="btn btn-sm btn-secondary dropdown-toggle" type="button" id="filterDropdown" data-bs-toggle="dropdown">
                            Filter Agents
                        </button>
                        <ul class="dropdown-menu p-3" style="min-width: 300px;">
                            <li>
                                <label class="form-label">Agency Name</label>
                                <select class="form-select" id="agencyFilter">
                                    <option value="">All</option>
                                    <?php
                                    // Fetch unique agency names from the database
                                    $stmt = $pdo->query("SELECT DISTINCT agency_name FROM Agents WHERE agency_name IS NOT NULL");
                                    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
                                        echo '<option value="' . htmlspecialchars($row['agency_name']) . '">' . htmlspecialchars($row['agency_name']) . '</option>';
                                    }
                                    ?>
                                </select>
                            </li>
                            <li>
                                <label class="form-label mt-2">Active Listings</label>
                                <select class="form-select" id="listingsFilter">
                                    <option value="">All</option>
                                    <option value="1-5">1-5</option>
                                    <option value="6-10">6-10</option>
                                    <option value="11-20">11-20</option>
                                    <option value="21+">21+</option>
                                </select>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>

            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-bordered">
                        <thead>
                            <tr>
                                <th>Profile Picture</th>
                                <th>Name</th>
                                <th>Email</th>
                                <th>Phone</th>
                                <th>License Number</th>
                                <th>Agency</th>
                                <th>Active Listings</th>
                                <th>Registered Date</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php foreach ($agents as $agent): ?>
                            <tr class="agent-row" 
                                data-agent-name="<?= strtolower(htmlspecialchars($agent['name'])) ?>"
                                data-email="<?= strtolower(htmlspecialchars($agent['email'])) ?>"
                                data-license="<?= strtolower(htmlspecialchars($agent['license_number'] ?? '')) ?>"
                                data-agency="<?= strtolower(htmlspecialchars($agent['agency_name'] ?? '')) ?>"
                                data-listings="<?= htmlspecialchars($agent['active_listings']) ?>">
                                <td>
                                <img src="../uploads/profile_pictures/<?php echo htmlspecialchars($agent['profile_picture'] ?? 'default-avatar.png'); ?>"

                                        class="rounded-circle" width="50" height="50" alt="Agent">
                                </td>
                                <td><?= htmlspecialchars($agent['name']) ?></td>
                                <td><?= htmlspecialchars($agent['email']) ?></td>
                                <td><?= htmlspecialchars($agent['phone_number'] ?? 'N/A') ?></td>
                                <td><?= htmlspecialchars($agent['license_number'] ?? 'N/A') ?></td>
                                <td><?= htmlspecialchars($agent['agency_name'] ?? 'N/A') ?></td>
                                <td><?= htmlspecialchars($agent['active_listings']) ?></td>
                                <td><?= htmlspecialchars($agent['created_at']) ?></td>
                                <td>
                                    <div class="btn-group">
                                        <a href="editAgent.php?agent_id=<?= $agent['agent_id'] ?>" class="btn btn-sm btn-outline-success">
                                            <i class="fas fa-edit"></i>
                                        </a>
                                        <a href="deleteAgent.php?agent_id=<?= $agent['agent_id'] ?>" class="btn btn-sm btn-outline-danger" onclick="confirmDelete(<?= $agent['agent_id'] ?>)">
                                            <i class="fas fa-trash"></i>
                                        </a>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                            <?php if (empty($agents)): ?>
                                <tr>
                                    <td colspan="8" class="text-center">No agents found.</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        <nav class="d-flex justify-content-center mt-4">
            <ul class="pagination">
                <?php for ($i = 1; $i <= $totalPages; $i++): ?>
                    <li class="page-item<?= $i == $page ? ' active' : '' ?>">
                        <a class="page-link" href="?page=<?= $i ?>"> <?= $i ?> </a>
                    </li>
                <?php endfor; ?>
            </ul>
        </nav>
    </div>

    <?php include "../footer.php"; ?>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>

        document.addEventListener("DOMContentLoaded", function () {
            const searchInput = document.getElementById("searchAgent");
            const agencyFilter = document.getElementById("agencyFilter");
            const listingsFilter = document.getElementById("listingsFilter");

            function filterResults() {
                const searchText = searchInput.value.toLowerCase();
                const selectedAgency = agencyFilter.value;
                const selectedListings = listingsFilter.value;
                console.log("Filtering triggered");

                document.querySelectorAll(".agent-row").forEach(row => {
                    const agentName = row.getAttribute("data-agent-name").toLowerCase();
                    const email = row.getAttribute("data-email").toLowerCase();
                    const licenseNumber = row.getAttribute("data-license").toLowerCase();
                    const agencyName = row.getAttribute("data-agency").trim().toLowerCase();
                    const activeListings = parseInt(row.getAttribute("data-listings") || "0", 10);

                    let matchesSearch = searchText === "" ||
                        agentName.includes(searchText) ||
                        email.includes(searchText) ||
                        licenseNumber.includes(searchText) ||
                        agencyName.includes(searchText);

                    let matchesAgency = selectedAgency === "" || agencyName === selectedAgency.toLowerCase();
                    let matchesListings = false;

                    if (selectedListings === "" || 
                        (selectedListings === "1-5" && activeListings >= 1 && activeListings <= 5) ||
                        (selectedListings === "6-10" && activeListings >= 6 && activeListings <= 10) ||
                        (selectedListings === "11-20" && activeListings >= 11 && activeListings <= 20) ||
                        (selectedListings === "21+" && activeListings >= 21)) {
                        matchesListings = true;
                    }

                    if (matchesSearch && matchesAgency && matchesListings) {
                        row.style.display = "";
                    } else {
                        row.style.display = "none";
                    }
                });
            }

            searchInput.addEventListener("input", filterResults);
            agencyFilter.addEventListener("change", filterResults);
            listingsFilter.addEventListener("change", filterResults);
        });

    </script>
</body>
</html>
