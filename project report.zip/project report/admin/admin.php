<?php
session_start();
include "../pdo.php";

// Check if the user is logged in and is an agent
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header('Location: ../login.php');
    exit();
}

// Check if agent_id is set in the session
if (!isset($_SESSION['admin_id'])) {
    die("Admin ID not found in session.");
}

$admin_id = $_SESSION['admin_id'];


try {
    // Fetch total properties
    $stmt = $pdo->query("SELECT COUNT(*) AS total_properties FROM Properties");
    $total_properties = $stmt->fetch(PDO::FETCH_ASSOC)['total_properties'];

    // Fetch active listings (status = 'available')
    $stmt = $pdo->query("SELECT COUNT(*) AS active_listings FROM Properties WHERE status = 'available'");
    $active_listings = $stmt->fetch(PDO::FETCH_ASSOC)['active_listings'];

    // Fetch total agents
    $stmt = $pdo->query("SELECT COUNT(*) AS total_agents FROM Agents");
    $total_agents = $stmt->fetch(PDO::FETCH_ASSOC)['total_agents'];

    // Fetch total users
    $stmt = $pdo->query("SELECT COUNT(*) AS total_users FROM Users WHERE role = 'user'");
    $total_users = $stmt->fetch(PDO::FETCH_ASSOC)['total_users'];

    // Fetch the 10 most recent properties with agent names
    $stmt = $pdo->query("
        SELECT p.property_id, p.title, p.property_type, p.price, p.status, 
               COALESCE(u.name, 'Unknown') AS agent_name
        FROM Properties p
        LEFT JOIN Agents a ON p.agent_id = a.agent_id
        LEFT JOIN Users u ON a.user_id = u.user_id
        ORDER BY p.created_at DESC
        LIMIT 10
    ");
    $properties = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Fetch recent inquiries (where agent_id is NULL)
    $stmtInquiries = $pdo->query("
        SELECT name, email, subject, message, created_at 
        FROM contact_messages 
        WHERE agent_id IS NULL 
        ORDER BY created_at DESC 
        LIMIT 5
    ");
    $inquiries = $stmtInquiries->fetchAll(PDO::FETCH_ASSOC);

    // Fetch upcoming appointments & consultations (where agent_id is NULL)
    $stmtAppointments = $pdo->query("
        SELECT first_name, last_name, appointment_date, time_slot, property_id, appointment_type 
        FROM appointments 
        WHERE agent_id IS NULL 
        ORDER BY appointment_date ASC, time_slot ASC 
        LIMIT 10
    ");
    $appointments = $stmtAppointments->fetchAll(PDO::FETCH_ASSOC);

} catch (PDOException $e) {
    die("Database error: " . $e->getMessage());
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>

    <!-- Favicon Links -->
    <link rel="apple-touch-icon" sizes="180x180" href="../Fonts/apple-touch-icon.png">
    <link rel="icon" type="image/png" sizes="32x32" href="../Fonts/favicon-32x32.png">

    <!-- CSS Links -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://unicons.iconscout.com/release/v4.0.8/css/line.css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css" rel="stylesheet">

</head>
<body class="d-flex flex-column min-vh-100">
    <?php include "../header.php"; ?>

    <div class="container-fluid d-flex justify-content-center">
        <!-- Main Content -->
        <main class="col-md-9 col-lg-10 px-md-4">
            <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                <h1 class="h2">Dashboard Overview</h1>
                <div class="btn-toolbar mb-2 mb-md-0">
                    <div class="btn-group me-2">
                        <button type="button" class="btn btn-sm btn-outline-primary">Export</button>
                    </div>
                </div>
            </div>

            <!-- Stats Cards -->
            <div class="row mb-4">
                <div class="col-xl-3 col-md-6 mb-4">
                    <a href="manageProperties.php" class="text-decoration-none">
                        <div class="card border-left-primary shadow h-100 py-2">
                            <div class="card-body">
                                <div class="row no-gutters align-items-center">
                                    <div class="col mr-2">
                                        <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">
                                            Total Properties</div>
                                        <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo $total_properties; ?></div>
                                    </div>
                                    <div class="col-auto">
                                        <i class="fas fa-building fa-2x text-gray-300"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </a>
                </div>

                <div class="col-xl-3 col-md-6 mb-4">
                    <a href="manageProperties.php?available=true" class="text-decoration-none">
                        <div class="card border-left-success shadow h-100 py-2">
                            <div class="card-body">
                                <div class="row no-gutters align-items-center">
                                    <div class="col mr-2">
                                        <div class="text-xs font-weight-bold text-success text-uppercase mb-1">
                                            Active Listings</div>
                                        <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo $active_listings; ?></div>
                                    </div>
                                    <div class="col-auto">
                                        <i class="fas fa-list fa-2x text-gray-300"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </a>
                </div>

                <div class="col-xl-3 col-md-6 mb-4">
                    <a href="manageAgents.php" class="text-decoration-none">
                        <div class="card border-left-info shadow h-100 py-2">
                            <div class="card-body">
                                <div class="row no-gutters align-items-center">
                                    <div class="col mr-2">
                                        <div class="text-xs font-weight-bold text-info text-uppercase mb-1">
                                            Total Agents</div>
                                        <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo $total_agents; ?></div>
                                    </div>
                                    <div class="col-auto">
                                        <i class="fas fa-user-tie fa-2x text-gray-300"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </a>
                </div>

                <div class="col-xl-3 col-md-6 mb-4">
                    <a href="manageUsers.php" class="text-decoration-none">
                        <div class="card border-left-warning shadow h-100 py-2">
                            <div class="card-body">
                                <div class="row no-gutters align-items-center">
                                    <div class="col mr-2">
                                        <div class="text-xs font-weight-bold text-warning text-uppercase mb-1">
                                            Total Users</div>
                                        <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo $total_users; ?></div>
                                    </div>
                                    <div class="col-auto">
                                        <i class="fas fa-message fa-2x text-gray-300"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </a>
                </div>
            </div>


            <!-- Property List -->
            <div class="card shadow mb-4">
                <div class="card-header py-3 d-flex justify-content-between align-items-center">
                    <h6 class="m-0 font-weight-bold text-primary">Recent Properties</h6>
                    <div class="dropdown">
                        <button class="btn btn-sm btn-secondary dropdown-toggle" type="button" id="filterDropdown" data-bs-toggle="dropdown">
                            Filter by Type
                        </button>
                        <ul class="dropdown-menu">
                            <li><a class="dropdown-item filter-option" href="#" data-type="all">All</a></li>
                            <li><a class="dropdown-item filter-option" href="#residential" data-type="residential">Residential</a></li>
                            <li><a class="dropdown-item filter-option" href="#commercial" data-type="commercial">Commercial</a></li>
                        </ul>
                    </div>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-bordered">
                            <thead>
                                <tr>
                                    <th>Title</th>
                                    <th>Type</th>
                                    <th>Price</th>
                                    <th>Status</th>
                                    <th>Agent</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody id="propertyTable">
                                <?php foreach ($properties as $property): ?>
                                    <tr class="property-row" data-type="<?php echo htmlspecialchars($property['property_type']); ?>">
                                        <td><?php echo htmlspecialchars($property['title']); ?></td>
                                        <td><?php echo ucfirst(htmlspecialchars($property['property_type'])); ?></td>
                                        <td>$<?php echo number_format($property['price'], 2); ?></td>
                                        <td>
                                            <?php
                                            $status_badge = [
                                                'available' => 'bg-success',
                                                'sold' => 'bg-danger',
                                                'rented' => 'bg-secondary'
                                            ];
                                            $status_class = $status_badge[$property['status']] ?? 'bg-warning';
                                            ?>
                                            <span class="badge <?php echo $status_class; ?>">
                                                <?php echo ucfirst($property['status']); ?>
                                            </span>
                                        </td>
                                        <td><?php echo htmlspecialchars($property['agent_name']); ?></td>
                                        <td>
                                            <a href="../agent/editProperties.php?property_id=<?php echo $property['property_id']; ?>" class="btn btn-sm btn-outline-success">Edit</a>
                                            <a href="../agent/deleteProperties.php?property_id=<?php echo $property['property_id']; ?>" class="btn btn-sm btn-outline-danger">Delete</a>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                                <?php if (empty($properties)): ?>
                                    <tr>
                                        <td colspan="6" class="text-center">No properties found.</td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

            <!-- Recent Inquiries -->
            <div class="row">
                <div class="col-lg-6">
                    <div class="card shadow mb-4">
                        <div class="card-header py-3">
                            <h6 class="m-0 font-weight-bold text-primary">Recent Inquiries</h6>
                        </div>
                        <div class="card-body">
                            <div class="list-group">
                                <?php if (empty($inquiries)): ?>
                                    <p class="text-muted">No recent inquiries.</p>
                                <?php else: ?>
                                    <?php foreach ($inquiries as $inquiry): ?>
                                        <a href="#" class="list-group-item list-group-item-action">
                                            <div class="d-flex w-100 justify-content-between">
                                                <h6 class="mb-1"><?php echo htmlspecialchars($inquiry['subject']); ?></h6>
                                                <small><?php echo date('M j, Y', strtotime($inquiry['created_at'])); ?></small>
                                            </div>
                                            <p class="mb-1"><?php echo htmlspecialchars(substr($inquiry['message'], 0, 50)) . '...'; ?></p>
                                            <small>From: <?php echo htmlspecialchars($inquiry['email']); ?></small>
                                        </a>
                                    <?php endforeach; ?>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Upcoming Appointments & Consultations -->
                <div class="col-lg-6">
                    <div class="card shadow mb-4">
                        <div class="card-header py-3">
                            <h6 class="m-0 font-weight-bold text-primary">Upcoming Appointments & Consultations</h6>
                        </div>
                        <div class="card-body">
                            <div class="list-group">
                                <?php if (empty($appointments)): ?>
                                    <p class="text-muted">No upcoming appointments or consultations.</p>
                                <?php else: ?>
                                    <?php foreach ($appointments as $appointment): ?>
                                        <a href="#" class="list-group-item list-group-item-action">
                                            <div class="d-flex w-100 justify-content-between">
                                                <h6 class="mb-1">
                                                    <?php 
                                                        echo $appointment['appointment_type'] == 'consultation' ? 
                                                        'Property Consultation' : 
                                                        'Property Viewing';
                                                    ?>
                                                </h6>
                                                <small><?php echo date('M j, Y', strtotime($appointment['appointment_date'])) . ", " . $appointment['time_slot']; ?></small>
                                            </div>
                                            <p class="mb-1">Property ID: <?php echo $appointment['property_id'] ?: 'N/A'; ?></p>
                                            <small>Client: <?php echo htmlspecialchars($appointment['first_name'] . ' ' . $appointment['last_name']); ?></small>
                                        </a>
                                    <?php endforeach; ?>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </main>
    </div>
    <?php include "../footer.php"; ?>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        document.addEventListener("DOMContentLoaded", function () {
            document.querySelectorAll(".filter-option").forEach(item => {
                item.addEventListener("click", function (event) {
                    event.preventDefault();
                    let selectedType = this.getAttribute("data-type");
                    
                    document.querySelectorAll(".property-row").forEach(row => {
                        if (selectedType === "all" || row.getAttribute("data-type") === selectedType) {
                            row.style.display = "";
                        } else {
                            row.style.display = "none";
                        }
                    });
                });
            });
        });
    </script>
   
</body>
</html>