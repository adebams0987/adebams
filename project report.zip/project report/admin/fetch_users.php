<?php
require '../pdo.php'; // Ensure database connection

$search = isset($_GET['search']) ? trim($_GET['search']) : '';
$statusFilter = isset($_GET['status']) ? $_GET['status'] : '';
$joinDate = isset($_GET['join_date']) ? $_GET['join_date'] : '';

try {
    $sql = "SELECT Users.user_id, Users.name, Users.email, Users.phone_number, Users.role, Users.created_at, 
                (SELECT COUNT(*) FROM saved_properties WHERE saved_properties.user_id = Users.user_id) AS saved_properties,
                CASE 
                    WHEN last_activity > NOW() - INTERVAL 5 MINUTE THEN 'online'
                    ELSE 'offline'
                END AS status
            FROM Users 
            WHERE role = 'user'";

    $params = [];

    // Search filter
    if (!empty($search)) {
        $sql .= " AND (name LIKE :search OR email LIKE :search OR phone_number LIKE :search)";
        $params[':search'] = "%$search%";
    }

    // Online status filter
    if (!empty($statusFilter)) {
        if ($statusFilter === 'online' || $statusFilter === 'offline') {
            $sql .= " AND (CASE WHEN last_activity > NOW() - INTERVAL 5 MINUTE THEN 'online' ELSE 'offline' END) = :status";
            $params[':status'] = $statusFilter;
        }
    }

    // Join date filter
    if (!empty($joinDate)) {
        $sql .= " AND DATE(created_at) = :join_date";
        $params[':join_date'] = $joinDate;
    }

    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    $users = $stmt->fetchAll(PDO::FETCH_ASSOC);

    header('Content-Type: application/json');
    echo json_encode($users);
} catch (PDOException $e) {
    echo json_encode(['error' => $e->getMessage()]);
}
?>
