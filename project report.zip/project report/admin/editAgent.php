<?php
require '../pdo.php';

// Check if agent_id is provided
if (!isset($_GET['agent_id']) || !is_numeric($_GET['agent_id'])) {
    die("Invalid agent ID.");
}

$agent_id = intval($_GET['agent_id']);

// Fetch agent details
$stmt = $pdo->prepare("
    SELECT a.agent_id, a.license_number, a.agency_name, a.profile_picture, 
           u.user_id, u.name, u.email, u.phone_number 
    FROM Agents a 
    JOIN Users u ON a.user_id = u.user_id 
    WHERE a.agent_id = ?
");
$stmt->execute([$agent_id]);
$agent = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$agent) {
    die("Agent not found.");
}

// Handle form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = trim($_POST['name']);
    $email = trim($_POST['email']);
    $phone = trim($_POST['phone']);
    $license_number = trim($_POST['license_number']);
    $agency_name = trim($_POST['agency_name']);
    $profile_picture = $agent['profile_picture']; // Default to existing profile picture

    // Handle profile picture upload
    if (!empty($_FILES['profile_picture']['name'])) {
        $target_dir = "../uploads/profile_pictures/";
        $target_file = $target_dir . basename($_FILES["profile_picture"]["name"]);
        
        if (move_uploaded_file($_FILES["profile_picture"]["tmp_name"], $target_file)) {
            $profile_picture = $target_file;
        }
    }

    try {
        // Begin transaction
        $pdo->beginTransaction();

        // Update Users table
        $stmt = $pdo->prepare("UPDATE Users SET name = ?, email = ?, phone_number = ? WHERE user_id = ?");
        $stmt->execute([$name, $email, $phone, $agent['user_id']]);

        // Update Agents table
        $stmt = $pdo->prepare("UPDATE Agents SET license_number = ?, agency_name = ?, profile_picture = ? WHERE agent_id = ?");
        $stmt->execute([$license_number, $agency_name, $profile_picture, $agent_id]);

        // Commit transaction
        $pdo->commit();

        header("Location: manageAgents.php?success=Agent updated successfully");
        exit;
    } catch (Exception $e) {
        $pdo->rollBack();
        echo "Error updating agent: " . $e->getMessage();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Agent</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="container mt-5">

    <h2 class="mb-4">Edit Agent</h2>

    <form method="POST" enctype="multipart/form-data" class="shadow p-4 rounded bg-white">
        <div class="mb-3">
            <label class="form-label">Full Name</label>
            <input type="text" name="name" class="form-control" value="<?= htmlspecialchars($agent['name']) ?>" required>
        </div>

        <div class="mb-3">
            <label class="form-label">Email</label>
            <input type="email" name="email" class="form-control" value="<?= htmlspecialchars($agent['email']) ?>" required>
        </div>

        <div class="mb-3">
            <label class="form-label">Phone Number</label>
            <input type="text" name="phone" class="form-control" value="<?= htmlspecialchars($agent['phone_number'] ?? '') ?>">
        </div>

        <div class="mb-3">
            <label class="form-label">License Number</label>
            <input type="text" name="license_number" class="form-control" value="<?= htmlspecialchars($agent['license_number'] ?? '') ?>">
        </div>

        <div class="mb-3">
            <label class="form-label">Agency Name</label>
            <input type="text" name="agency_name" class="form-control" value="<?= htmlspecialchars($agent['agency_name'] ?? '') ?>">
        </div>

        <div class="mb-3">
            <label class="form-label">Profile Picture</label>
            <input type="file" name="profile_picture" class="form-control">
            <div class="mt-2">
                <img src="<?= htmlspecialchars($agent['profile_picture'] ?? '/default-avatar.png') ?>" width="100" height="100" class="rounded-circle">
            </div>
        </div>

        <button type="submit" class="btn btn-primary">Update Agent</button>
        <a href="manageAgents.php" class="btn btn-secondary">Cancel</a>
    </form>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
