<?php
session_start();
require "../pdo.php";

// Check if the user is logged in and is an admin
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header('Location: ../login.php');
    exit();
}

// Ensure admin_id is set
if (!isset($_SESSION['admin_id'])) {
    die("Admin ID not found in session.");
}

$admin_id = $_SESSION['admin_id'];
$limit = 20; // Agents per page
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$offset = ($page - 1) * $limit;

try {
    // Fetch total user count
    $stmt = $pdo->query("SELECT COUNT(*) AS total_users FROM Users WHERE role = 'user'");
    $totalUsers = $stmt->fetch(PDO::FETCH_ASSOC)['total_users'];

    // Fetch total saved properties
    $stmt = $pdo->query("SELECT COUNT(*) AS saved_properties FROM saved_properties");
    $savedProperties = $stmt->fetch(PDO::FETCH_ASSOC)['saved_properties'];

    // Fetch active (future) appointments
    $stmt = $pdo->prepare("
        SELECT COUNT(*) AS active_appointments 
        FROM appointments 
        WHERE appointment_date > CURDATE() 
        OR (appointment_date = CURDATE() AND STR_TO_DATE(time_slot, '%H:%i') > CURTIME())
    ");
    $stmt->execute();
    $activeAppointments = $stmt->fetch(PDO::FETCH_ASSOC)['active_appointments'];

    // Fetch total inquiries
    $stmt = $pdo->query("SELECT COUNT(*) AS inquiries FROM contact_messages");
    $totalInquiries = $stmt->fetch(PDO::FETCH_ASSOC)['inquiries'];

    // Fetch user details with saved properties count
    $query = "SELECT Users.user_id, Users.name, Users.email, Users.phone_number, Users.role, Users.created_at, 
                (SELECT COUNT(*) FROM saved_properties WHERE saved_properties.user_id = Users.user_id) AS saved_properties,
                CASE 
                    WHEN last_activity > NOW() - INTERVAL 5 MINUTE THEN 'online'
                    ELSE 'offline'
                END AS status
          FROM Users WHERE role = 'user' LIMIT ? OFFSET ?";
    $stmt = $pdo->prepare($query);
    $stmt->bindValue(1, $limit, PDO::PARAM_INT);
    $stmt->bindValue(2, $offset, PDO::PARAM_INT);
    $stmt->execute();
    $users = $stmt->fetchAll(PDO::FETCH_ASSOC);

} catch (PDOException $e) {
    die("Database error: " . $e->getMessage());
}

$totalPages = ceil($totalUsers / $limit);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>

    <!-- Favicon -->
    <link rel="icon" type="image/png" sizes="32x32" href="../Fonts/favicon-32x32.png">

    <!-- Bootstrap & External Styles -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600;700&display=swap" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css" rel="stylesheet">

    <style>
        body {
            font-family: 'Poppins', sans-serif;
            background-color: #f8f9fc;
        }
        .card-custom {
            border-radius: 12px;
            transition: 0.3s;
        }
        .card-custom:hover {
            box-shadow: 0px 4px 12px rgba(0, 0, 0, 0.1);
        }
        .table-hover tbody tr:hover {
            background-color: #f1f3f5;
        }
        .centered-table th, .centered-table td {
            text-align: center;
            vertical-align: middle;
        }
    </style>
</head>
<body class="d-flex flex-column min-vh-100">
    <?php include "../header.php"; ?>

    <div class="container py-4">
        <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
            <h1 class="h2">Manage Users</h2>
            <div class="btn-toolbar mb-2 mb-md-0">
                <div class="btn-group me-2">
                    <button type="button" class="btn btn-sm btn-outline-primary">Export</button>
                </div>
            </div>
        </div>

        <div class="row mb-4">
            <?php
            $dashboardItems = [
                ["icon" => "fas fa-users", "color" => "primary", "title" => "Total Users", "value" => $totalUsers],
                ["icon" => "fas fa-heart", "color" => "danger", "title" => "Saved Properties", "value" => $savedProperties],
                ["icon" => "fas fa-calendar", "color" => "success", "title" => "Active Appointments", "value" => $activeAppointments],
                ["icon" => "fas fa-envelope", "color" => "info", "title" => "Inquiries", "value" => $totalInquiries]
            ];

            foreach ($dashboardItems as $item): ?>
                <div class="col-md-3">
                    <div class="card border-0 shadow-sm">
                        <div class="card-body text-center">
                            <i class="<?= $item['icon'] ?> fa-2x text-<?= $item['color'] ?> mb-2"></i>
                            <h5><?= $item['title'] ?></h5>
                            <h3><?= number_format($item['value']) ?></h3>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
        

        <div class="card shadow mb-4">
            <div class="card-header py-3 d-flex justify-content-between align-items-center">
                <div class="col-md-6">
                    <div class="input-group">
                        <span class="input-group-text bg-white border-end-0">
                            <i class="fas fa-search text-muted"></i>
                        </span>
                        <input type="text" class="form-control border-start-0" id="searchUser" placeholder="Search...">
                    </div>
                </div>
                <div class="col-md-6 text-md-end">
                    <div class="dropdown">
                        <button class="btn btn-sm btn-secondary dropdown-toggle" type="button" id="filterDropdown" data-bs-toggle="dropdown">
                            Filter Users
                        </button>
                        <ul class="dropdown-menu p-3" style="min-width: 300px;">
                            <li>
                                <label class="form-label">Online Status</label>
                                <select class="form-select" id="statusFilter">
                                    <option value="">All</option>
                                    <option value="online">Online</option>
                                    <option value="offline">Offline</option>
                                </select>
                            </li>
                            <li>
                                <label class="form-label mt-2">Join Date</label>
                                <input type="date" class="form-control" id="joinDateFilter">
                            </li>
                            <li class="mt-3 text-end">
                                <button class="btn btn-sm btn-primary" onclick="applyFilters()">Apply</button>
                                <button class="btn btn-sm btn-secondary" onclick="resetFilters()">Reset</button>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>

            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-bordered text-center table-hover">
                        <thead>
                            <tr>
                                <th scope="col">User Name</th>
                                <th scope="col">Email</th>
                                <th scope="col">Phone</th>
                                <th scope="col">Saved Properties</th>
                                <th scope="col">Join Date</th>
                                <th scope="col">Status</th>
                                <th scope="col">Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php foreach ($users as $row): ?>
                            <tr>
                                <td>
                                    <div class="fw-bold"><?= htmlspecialchars($row['name']) ?></div>
                                </td>
                                <td>
                                    <div><?= htmlspecialchars($row['email']) ?></div>
                                </td>
                                <td><?= htmlspecialchars($row['phone_number'] ?? 'N/A') ?></td>
                                <td><?= htmlspecialchars($row['saved_properties']) ?></td>
                                <td><?= date('M d, Y', strtotime($row['created_at'])) ?></td>
                                <td>
                                    <?php if ($row['status'] === 'online'): ?>
                                        <span class="badge bg-success">Online</span>
                                    <?php else: ?>
                                        <span class="badge bg-secondary">Offline</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <button class="btn btn-sm btn-outline-primary me-1 edit-btn" data-id="<?= $row['user_id'] ?>">
                                        <i class="fas fa-edit"></i>
                                    </button>
                                    <button class="btn btn-sm btn-outline-info me-1 view-btn" data-id="<?= $row['user_id'] ?>">
                                        <i class="fas fa-eye"></i>
                                    </button>
                                    <button class="btn btn-sm btn-outline-danger delete-btn" data-id="<?= $row['user_id'] ?>">
                                        <i class="fas fa-trash"></i>
                                    </button>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                            <?php if (empty($users)): ?>
                                <tr>
                                    <td colspan="8" class="text-center">No users found.</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        <nav class="d-flex justify-content-center mt-4">
            <ul class="pagination">
                <?php for ($i = 1; $i <= $totalPages; $i++): ?>
                    <li class="page-item<?= $i == $page ? ' active' : '' ?>">
                        <a class="page-link" href="?page=<?= $i ?>"> <?= $i ?> </a>
                    </li>
                <?php endfor; ?>
            </ul>
        </nav>
    </div>

    <div class="modal fade" id="editUserModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Edit User</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <form id="editUserForm">
                        <input type="hidden" id="editUserId">
                        <div class="mb-3">
                            <label class="form-label">Name</label>
                            <input type="text" class="form-control" id="editUserName">
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Email</label>
                            <input type="email" class="form-control" id="editUserEmail">
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Phone</label>
                            <input type="text" class="form-control" id="editUserPhone">
                        </div>
                        <button type="submit" class="btn btn-primary">Save Changes</button>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <div class="modal fade" id="viewUserModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">User Details</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <p><strong>Name:</strong> <span id="viewUserName"></span></p>
                    <p><strong>Email:</strong> <span id="viewUserEmail"></span></p>
                    <p><strong>Phone:</strong> <span id="viewUserPhone"></span></p>
                    <p><strong>Join Date:</strong> <span id="viewJoinDate"></span></p>
                </div>
            </div>
        </div>
    </div>


    <?php include "../footer.php"; ?>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        document.getElementById('searchUser').addEventListener('input', applyFilters);
        function applyFilters() {
        let searchValue = document.getElementById('searchUser').value.trim();
        let status = document.getElementById('statusFilter').value;
        let joinDate = document.getElementById('joinDateFilter').value;

        let url = `fetch_users.php?search=${encodeURIComponent(searchValue)}&status=${encodeURIComponent(status)}&join_date=${encodeURIComponent(joinDate)}`;

        fetch(url)
            .then(response => response.json())
            .then(data => {
                let tbody = document.querySelector("tbody");
                tbody.innerHTML = ""; // Clear existing table rows

                if (data.length === 0) {
                    tbody.innerHTML = `<tr><td colspan="7" class="text-center">No users found.</td></tr>`;
                    return;
                }

                data.forEach(row => {
                    let statusBadge = row.status === 'online' 
                        ? '<span class="badge bg-success">Online</span>' 
                        : '<span class="badge bg-secondary">Offline</span>';

                    let joinDateFormatted = new Date(row.created_at).toLocaleDateString('en-US', {
                        month: 'short', day: '2-digit', year: 'numeric'
                    });

                    tbody.innerHTML += `
                        <tr>
                            <td><div class="fw-bold">${row.name}</div></td>
                            <td><div>${row.email}</div></td>
                            <td>${row.phone_number || 'N/A'}</td>
                            <td>${row.saved_properties}</td>
                            <td>${joinDateFormatted}</td>
                            <td>${statusBadge}</td>
                            <td>
                                <button class="btn btn-sm btn-outline-primary me-1"><i class="fas fa-edit"></i></button>
                                <button class="btn btn-sm btn-outline-info me-1"><i class="fas fa-eye"></i></button>
                                <button class="btn btn-sm btn-outline-danger"><i class="fas fa-trash"></i></button>
                            </td>
                        </tr>`;
                });
            })
            .catch(error => console.error("Error fetching users:", error));
        }

        // Reset Filters
        function resetFilters() {
            document.getElementById('searchUser').value = '';
            document.getElementById('statusFilter').value = '';
            document.getElementById('joinDateFilter').value = '';
            applyFilters(); // Refresh table
        }

        // Search input event listener
        document.getElementById('searchUser').addEventListener('keyup', applyFilters);
    </script>

</body>
</html>
