<?php
session_start();
include "../pdo.php";

// Check if the user is logged in and is an agent
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header('Location: ../login.php');
    exit();
}

// Check if agent_id is set in the session
if (!isset($_SESSION['admin_id'])) {
    die("Admin ID not found in session.");
}

$admin_id = $_SESSION['admin_id'];

$limit = 20; // Properties per page
$page = isset($_GET['page']) ? (int) $_GET['page'] : 1;
$offset = ($page - 1) * $limit;

try {
    // Base query
    $query = "SELECT * FROM properties";
    $params = [];

    // Check if the 'available' filter is applied
    if (isset($_GET['available']) && $_GET['available'] === 'true') {
        $query .= " WHERE status = :status";
        $params[':status'] = 'available';
    }

    // Prepare and execute the query
    $stmt = $pdo->prepare($query);
    $stmt->execute($params);
    $properties = $stmt->fetchAll();
} catch (PDOException $e) {
    die("Database error: " . $e->getMessage());
}

try {
    $query = "
        SELECT p.property_id, p.title, p.price, p.property_type, p.listing_type, p.status, p.created_at AS listed_date,
            CONCAT(p.address, ', ', p.city, ', ', p.state) AS location,
            u.name AS agent_name,
            (SELECT pi.image_url FROM Property_Images pi WHERE pi.property_id = p.property_id ORDER BY pi.image_id ASC LIMIT 1) AS image_url
        FROM Properties p
        LEFT JOIN Agents a ON p.agent_id = a.agent_id
        LEFT JOIN Users u ON a.user_id = u.user_id
        ORDER BY p.created_at DESC
        LIMIT :limit OFFSET :offset
    ";

    $stmt = $pdo->prepare($query);
    $stmt->bindValue(':limit', $limit, PDO::PARAM_INT);
    $stmt->bindValue(':offset', $offset, PDO::PARAM_INT);
    $stmt->execute();
    $properties = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Fetch total properties count
    $totalStmt = $pdo->query("SELECT COUNT(*) FROM Properties");
    $totalProperties = $totalStmt->fetchColumn();
    $totalPages = ceil($totalProperties / $limit);
} catch (PDOException $e) {
    die("Database error: " . $e->getMessage());
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>

    <!-- Favicon Links -->
    <link rel="apple-touch-icon" sizes="180x180" href="../Fonts/apple-touch-icon.png">
    <link rel="icon" type="image/png" sizes="32x32" href="../Fonts/favicon-32x32.png">

    <!-- CSS Links -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://unicons.iconscout.com/release/v4.0.8/css/line.css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css" rel="stylesheet">

</head>
<body class="d-flex flex-column min-vh-100">
    <?php include "../header.php"; ?>

    <div class="container-fluid d-flex justify-content-center">
        <!-- Main Content -->
        <main class="col-md-9 col-lg-10 px-md-4">
            <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                <h1 class="h2">Property Management</h1>
                <div class="btn-toolbar mb-2 mb-md-0">
                    <div class="btn-group me-2">
                        <button type="button" class="btn btn-sm btn-outline-primary">Export</button>
                    </div>
                </div>
            </div>

            
            <!-- Property List -->
            <div class="card shadow mb-4">
                <div class="card-header py-3 d-flex justify-content-between align-items-center">
                    <h6 class="m-0 font-weight-bold text-primary">Properties</h6>
                    <div class="dropdown">
                        <button class="btn btn-sm btn-secondary dropdown-toggle" type="button" id="filterDropdown" data-bs-toggle="dropdown">
                            Filter Properties
                        </button>
                        <ul class="dropdown-menu p-3" style="min-width: 300px;">
                            <li>
                                <label class="form-label">Property Type</label>
                                <select class="form-select" id="propertyTypeFilter">
                                    <option value="">All</option>
                                    <option value="residential">Residential</option>
                                    <option value="commercial">Commercial</option>
                                </select>
                            </li>
                            <li>
                                <label class="form-label mt-2">Listing Type</label>
                                <select class="form-select" id="listingTypeFilter">
                                    <option value="">All</option>
                                    <option value="sale">For Sale</option>
                                    <option value="rent">For Rent</option>
                                </select>
                            </li>
                            <li>
                                <label class="form-label mt-2">Status</label>
                                <select class="form-select" id="statusFilter">
                                    <option value="" <?php echo !isset($_GET['available']) ? 'selected' : ''; ?>>All</option>
                                    <option value="available" <?php echo (isset($_GET['available']) && $_GET['available'] === 'true') ? 'selected' : ''; ?>>Available</option>
                                    <option value="sold">Sold</option>
                                    <option value="rented">Rented</option>
                                </select>
                            </li>
                            <li>
                                <label class="form-label mt-2">Search</label>
                                <input type="text" class="form-control" id="searchProperty" placeholder="Search properties...">
                            </li>
                        </ul>
                    </div>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-bordered">
                            <thead>
                                <tr>
                                    <th>Image</th>
                                    <th>Title</th>
                                    <th>Type</th>
                                    <th>Price</th>
                                    <th>Location</th>
                                    <th>Status</th>
                                    <th>Listed Date</th>
                                    <th>Agent</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody id="propertyTable">
                                <?php foreach ($properties as $property): ?>
                                    <tr class="property-row" data-type="<?php echo htmlspecialchars($property['property_type'] ?? ''); ?>" data-listing-type="<?php echo htmlspecialchars($property['listing_type'] ?? ''); ?>" data-status="<?php echo htmlspecialchars($property['status'] ?? ''); ?>">
                                    <td>
                                        <img src="<?php echo !empty($property['image_url']) ? htmlspecialchars($property['image_url']) : '/api/placeholder/50/50'; ?>" class="rounded" width="50" height="50" alt="Property Image">
                                    </td>
                                        <td><?php echo htmlspecialchars($property['title'] ?? ''); ?></td>
                                        <td><span class="badge bg-primary"> <?php echo ucfirst(htmlspecialchars($property['property_type'] ?? '')); ?> </span></td>
                                        <td>$<?php echo number_format($property['price'] ?? 0, 2); ?></td>
                                        <td><?php echo htmlspecialchars($property['location'] ?? ''); ?></td>
                                        <td>
                                            <?php
                                            $status_badge = [
                                                'available' => 'bg-success',
                                                'sold' => 'bg-danger',
                                                'rented' => 'bg-secondary',
                                                'pending' => 'bg-warning'
                                            ];
                                            $status_class = $status_badge[$property['status']] ?? 'bg-warning';
                                            ?>
                                            <span class="badge <?php echo $status_class; ?>">
                                                <?php echo ucfirst($property['status'] ?? ''); ?>
                                            </span>
                                        </td>
                                        <td><?php echo htmlspecialchars($property['listed_date'] ?? ''); ?></td>
                                        <td><?php echo htmlspecialchars($property['agent_name'] ?? ''); ?></td>
                                        <td>
                                            <div class="btn-group">
                                                <a href="../agent/editProperties.php?property_id=<?php echo $property['property_id']; ?>" class="btn btn-sm btn-outline-success">
                                                    <i class="fas fa-edit"></i>
                                                </a>
                                                <a href="../agent/deleteProperties.php?property_id=<?php echo $property['property_id']; ?>" class="btn btn-sm btn-outline-danger">
                                                    <i class="fas fa-trash"></i>
                                                </a>
                                                <a href="../property_details.php?property_id=<?php echo $property['property_id']; ?>" class="btn btn-sm btn-outline-info">
                                                    <i class="fas fa-eye"></i>
                                                </a>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                                <?php if (empty($properties)): ?>
                                    <tr>
                                        <td colspan="10" class="text-center">No properties found.</td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

            <!-- Pagination -->
            <nav class="d-flex justify-content-center">
                <ul class="pagination">
                    <?php for ($i = 1; $i <= $totalPages; $i++): ?>
                        <li class="page-item<?= $i == $page ? ' active' : '' ?>">
                            <a class="page-link" href="?page=<?= $i ?>"> <?= $i ?> </a>
                        </li>
                    <?php endfor; ?>
                </ul>
            </nav>

        </main>
    </div>
    
    <?php include "../footer.php"; ?>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        document.addEventListener("DOMContentLoaded", function () {
            function filterProperties() {
                let selectedType = document.getElementById("propertyTypeFilter").value;
                let selectedListing = document.getElementById("listingTypeFilter").value;
                let selectedStatus = document.getElementById("statusFilter").value;
                let searchQuery = document.getElementById("searchProperty").value.toLowerCase();

                document.querySelectorAll(".property-row").forEach(row => {
                    let typeMatch = selectedType === "" || row.getAttribute("data-type") === selectedType;
                    let listingMatch = selectedListing === "" || row.getAttribute("data-listing-type") === selectedListing;
                    let statusMatch = selectedStatus === "" || row.getAttribute("data-status") === selectedStatus;
                    let searchMatch = searchQuery === "" || row.innerText.toLowerCase().includes(searchQuery);

                    if (typeMatch && listingMatch && statusMatch && searchMatch) {
                        row.style.display = "";
                    } else {
                        row.style.display = "none";
                    }
                });
            }

            document.getElementById("propertyTypeFilter").addEventListener("change", filterProperties);
            document.getElementById("listingTypeFilter").addEventListener("change", filterProperties);
            document.getElementById("statusFilter").addEventListener("change", filterProperties);
            document.getElementById("searchProperty").addEventListener("input", filterProperties);
        });
    </script>
</body>
</html>